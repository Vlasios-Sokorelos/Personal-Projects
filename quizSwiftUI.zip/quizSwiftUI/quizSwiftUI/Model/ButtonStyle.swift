//
//  ButtonStyle.swift
//  quizSwiftUI
//
//  Created by ΒΛΑΣΗΣ ΣΟΚΟΡΕΛΟΣ on 8/6/24.
//

import Foundation
import SwiftUI

struct ButtonStyleModifier: ViewModifier {
    let isSelected: Bool
    let isCorrect: Bool
    let isCurrentAnswer: Bool
    
    func body(content: Content) -> some View {
        content
            .padding()
            .background(
                isSelected ?
                    (isCorrect ? Color.green : Color.red) :
                    (isCurrentAnswer ? Color.green : Color(red: 0.9137254901960784, green: 0.9137254901960784, blue: 0.9215686274509803))
            )
            .foregroundColor(
                isSelected ?
                    (isCorrect ? Color.white : Color.white) :
                    (isCurrentAnswer ? Color.white : Color(red: 0.20784313725490197, green: 0.47058823529411764, blue: 0.9647058823529412))
            )
            .cornerRadius(10)
    }
}

extension View {
    func customButtonStyle(isSelected: Bool, isCorrect: Bool, isCurrentAnswer: Bool) -> some View {
        self.modifier(ButtonStyleModifier(isSelected: isSelected, isCorrect: isCorrect, isCurrentAnswer: isCurrentAnswer))
    }
}
