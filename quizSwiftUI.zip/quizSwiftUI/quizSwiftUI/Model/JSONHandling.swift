//
//  JSONHandling.swift
//  quizUIKit
//
//  Created by ΒΛΑΣΗΣ ΣΟΚΟΡΕΛΟΣ on 8/6/24.
//

import Foundation


func loadJSONFile(filename: String) -> Data?{
    if let path = Bundle.main.path(forResource: filename, ofType: "json"){
        do {
            let data = try Data(contentsOf: URL(fileURLWithPath: path))
            return data
        }
        catch {
            print("Error loading JSON file: \(error)")
        }
    }
    return nil
}

func decodeJSONFile(data: Data) -> [Question]? {
    let decoder = JSONDecoder()
    do {
        let questions = try decoder.decode([Question].self, from: data)
        return questions
    }
    catch {
        print("Error decoding JSON file: \(error)")
    }
    return nil
}

func createQuestionList() -> [Question]{
    
    var tempListOfQuestions: [Question] = []
    
    if let jsonData = loadJSONFile(filename: "swiftQuestionsJSON") {
        if let questions = decodeJSONFile(data: jsonData) {
            for question in questions {
                let tempQuestionText = question.question
                let tempQuestionAnswer = question.answer
                let newQuestion = Question(question: tempQuestionText, answer: tempQuestionAnswer)
                tempListOfQuestions.append(newQuestion)
            }
            
        }
        else {
            print("Error decoding data")
        }
    }
    else {
        print("Error loading data")
    }
    return tempListOfQuestions
}


