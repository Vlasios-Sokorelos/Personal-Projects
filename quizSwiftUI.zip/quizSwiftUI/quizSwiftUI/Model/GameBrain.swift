//
//  GameBrain.swift
//  quizUIKit
//
//  Created by ΒΛΑΣΗΣ ΣΟΚΟΡΕΛΟΣ on 8/6/24.
//

import Foundation

class GameBrain{
    
    var questionList: [Question] = []
    var currentScore: Int = 0
    var currentQuestion: Int = 0
    
    static let shared = GameBrain()
    
    private init(){
        
    }
    
    func createDefaultGame(){
        questionList = createQuestionList()
        currentScore = 0
        currentQuestion = 0
    }
    
    func createRandomGame(quizSize: Int){
        var tempQuestionList: [Question] = createQuestionList()
        var finalQuestionList: [Question] = []
        for _ in 0..<quizSize {
            let randomIndex = Int.random(in: 0..<tempQuestionList.count)
            finalQuestionList.append(tempQuestionList[randomIndex])
            tempQuestionList.remove(at: randomIndex)
        }
        questionList = finalQuestionList
        currentScore = 0
        currentQuestion = 0
    }
    
    
    func correctAnswer(userAnswer: String) -> Bool{
        if (questionList[currentQuestion].answer == userAnswer) {
            currentScore = currentScore + 1
            return true
        }
        else {
            return false
        }
    }
    
    func nextQuestion() -> Bool{
        if currentQuestion < questionList.count - 1{
            currentQuestion = currentQuestion + 1
            return true
        }
        else {
            return false
        }
    }
    
    func sortList(){
        questionList.sort(by: <)
    }
    
    
    func getMessage() -> String{
        
        let maxScore = questionList.count
        var result: String
        if (currentScore == maxScore){
            result = "Perfect Win!"
        }
        else if (currentScore > (maxScore/2)){
            result = "Win!"
        }
        else {
            result = "Loss!"
        }
        return "You got \(currentScore) out of \(maxScore):\n \(result)"
        
    }
}
