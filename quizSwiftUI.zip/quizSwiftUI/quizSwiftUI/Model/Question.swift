//
//  Question.swift
//  quizUIKit
//
//  Created by ΒΛΑΣΗΣ ΣΟΚΟΡΕΛΟΣ on 8/6/24.
//

import Foundation

struct Question: Codable, Comparable, Hashable{
    
    
    let question: String
    let answer: String
    
    static func < (lhs: Question, rhs: Question) -> Bool {
        return lhs.question < rhs.question
    }
    
    
}
