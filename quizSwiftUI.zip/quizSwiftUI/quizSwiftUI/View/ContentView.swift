//
//  ContentView.swift
//  quizSwiftUI
//
//  Created by ΒΛΑΣΗΣ ΣΟΚΟΡΕΛΟΣ on 8/6/24.
//

import SwiftUI

struct ContentView: View {
    @State private var transferToQuiz: Bool = false
    @State private var transferToList: Bool = false
    let gameBrain = GameBrain.shared
    
    var body: some View {
        NavigationView {
            VStack(spacing: 10) { // Adjust the spacing as needed
                Text("Swift Programming Theory Quiz")
                    .font(.title)
                
                NavigationLink(
                    destination: QuizScreen(),
                    isActive: $transferToQuiz,
                    label: {
                        Button(action: {
                            // Execute your function here
                            gameBrain.createDefaultGame()
                            // Set the state variable to true to trigger navigation
                            transferToQuiz = true
                        }) {
                            Text("Play Normal Game")
                                .padding()
                                .background(Color(red: 0.9137254901960784, green: 0.9137254901960784, blue: 0.9215686274509803))
                                .foregroundColor(Color(red: 0.20784313725490197, green: 0.47058823529411764, blue: 0.9647058823529412))
                                .cornerRadius(10)
                        }
                    })
                NavigationLink(
                    destination: QuizScreen(),
                    isActive: $transferToQuiz,
                    label: {
                        Button(action: {
                            // Execute your function here
                            gameBrain.createRandomGame(quizSize: 5)
                            // Set the state variable to true to trigger navigation
                            transferToQuiz = true
                        }) {
                            Text("Play Random Game")
                                .padding()
                                .background(Color(red: 0.9137254901960784, green: 0.9137254901960784, blue: 0.9215686274509803))
                                .foregroundColor(Color(red: 0.20784313725490197, green: 0.47058823529411764, blue: 0.9647058823529412))
                                .cornerRadius(10)
                        }
                    })
                
                NavigationLink(
                    destination: QuestionList(),
                    isActive: $transferToList,
                    label: {
                        Button(action: {
                            // Execute your function here
                            gameBrain.createDefaultGame()
                            // Set the state variable to true to trigger navigation
                            transferToList = true
                        }) {
                            Text("Show Questions")
                                .padding()
                                .background(Color(red: 0.20784313725490197, green: 0.47058823529411764, blue: 0.9647058823529412))
                                .foregroundColor(.white)
                                .cornerRadius(10)
                        }
                    })
            }
        }
    }
}



#Preview {
    ContentView()
}
