//
//  ResultScreen.swift
//  quizSwiftUI
//
//  Created by ΒΛΑΣΗΣ ΣΟΚΟΡΕΛΟΣ on 8/6/24.
//

import SwiftUI

struct ResultScreen: View {
    @Environment(\.presentationMode) var presentationMode
    @State private var returnToQuiz = false // State variable to trigger return to quiz screen
    let gameBrain = GameBrain.shared
    
    var body: some View {
        VStack {
            Text(gameBrain.getMessage())
            
            
            
            Button(action: {
                gameBrain.currentQuestion = 0
                gameBrain.currentScore = 0
                returnToQuiz = true // Trigger return to quiz screen
            }) {
                Text("Play Again")
                    .padding()
                    .background(Color(red: 0.8352941176470589, green: 0.9058823529411765, blue: 0.9921568627450981))
                    .foregroundColor(.blue)
                    .cornerRadius(10)
            }
        }
        .background(
            NavigationLink(
                destination: QuizScreen(), // Navigate to QuizScreen when returnToQuiz is true
                isActive: $returnToQuiz,
                label: {
                    EmptyView()
                })
        )
        
        Button(action: {
            dismissToRootView()
        }) {
            Text("Return To Main Menu")
                .padding()
                .background(Color(red: 0.20784313725490197, green: 0.47058823529411764, blue: 0.9647058823529412))
                .foregroundColor(.white)
                .cornerRadius(10)
        }
        .navigationBarBackButtonHidden(true) // Hide the back button
        .navigationBarHidden(true) // Hide the navigation bar
    }
    
    
    func dismissToRootView() {
        // Dismiss all views and return to the root view controller (main menu screen)
        self.presentationMode.wrappedValue.dismiss()
        UIApplication.shared.windows.first?.rootViewController = UIHostingController(rootView: ContentView())
    }
}



#Preview {
    ResultScreen()
}
