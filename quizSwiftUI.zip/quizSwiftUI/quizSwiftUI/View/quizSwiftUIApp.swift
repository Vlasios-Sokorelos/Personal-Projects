//
//  quizSwiftUIApp.swift
//  quizSwiftUI
//
//  Created by ΒΛΑΣΗΣ ΣΟΚΟΡΕΛΟΣ on 8/6/24.
//

import SwiftUI

@main
struct quizSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
