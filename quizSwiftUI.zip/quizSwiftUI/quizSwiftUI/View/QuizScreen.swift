//
//  QuizScreen.swift
//  quizSwiftUI
//
//  Created by ΒΛΑΣΗΣ ΣΟΚΟΡΕΛΟΣ on 8/6/24.
//

import SwiftUI

struct QuizScreen: View {

    let gameBrain = GameBrain.shared
    
    @State private var selectedAnswer: String? = nil
    @State private var isCorrectAnswer: Bool? = nil
    @State private var correctAnswer: String? = ""
    @State private var isButtonDisabled = false // Added state variable to control button's enabled state
    @State private var showResultScreen = false
    
    var body: some View {
        VStack {
            Text("Question \(gameBrain.currentQuestion+1) out of \(gameBrain.questionList.count)").padding()
            Text(gameBrain.questionList[gameBrain.currentQuestion].question)
            
            // Button grid creation with a 2x2 layout
            ButtonGrid(selectedAnswer: $selectedAnswer,
                       isCorrectAnswer: $isCorrectAnswer,
                       correctAnswer: $correctAnswer,
                       checkAnswer: checkAnswer)
            .disabled(isButtonDisabled) // Disable buttons when isButtonDisabled is true
        }
        NavigationLink(destination: ResultScreen(), isActive: $showResultScreen) {
            EmptyView() // This is hidden; navigation happens programmatically
        }
    }
    
    func checkAnswer(_ answer: String) {
        guard selectedAnswer != answer else {
                return
            }
        selectedAnswer = answer
        
       
        if gameBrain.correctAnswer(userAnswer: answer) {
            isCorrectAnswer = true
        } else {
            isCorrectAnswer = false
            correctAnswer = gameBrain.questionList[gameBrain.currentQuestion].answer
        }
        
        // Start the timer after the user has pressed an answer
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            // After 2 seconds, move to the next question
            if gameBrain.nextQuestion() {
                selectedAnswer = nil // Reset selectedAnswer
                isCorrectAnswer = nil // Reset isCorrectAnswer
                correctAnswer = nil
                isButtonDisabled = false // Re-enable buttons
            } else {
                showResultScreen = true
                
            }
        }
        
        // Disable buttons while waiting for 2 seconds
        isButtonDisabled = true
    }
}

#Preview {
    let gameBrain = GameBrain.shared
    gameBrain.createRandomGame(quizSize: 2) // Create a default game with a predefined question list
    
    return QuizScreen()
    
}
