//
//  QuestionDetails.swift
//  quizSwiftUI
//
//  Created by ΒΛΑΣΗΣ ΣΟΚΟΡΕΛΟΣ on 8/6/24.
//

import SwiftUI

struct QuestionDetails: View {
    @State var question: Question
    
    var body: some View {
        VStack{
            Text(question.question)
            Text("Correct Answer is: " + question.answer)
        }
    }
}

#Preview {
    QuestionDetails(question: Question(question: "Test1", answer: "A"))
}
