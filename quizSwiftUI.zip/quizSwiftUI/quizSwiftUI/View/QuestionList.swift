//
//  QuestionList.swift
//  quizSwiftUI
//
//  Created by ΒΛΑΣΗΣ ΣΟΚΟΡΕΛΟΣ on 8/6/24.
//

import SwiftUI

struct QuestionList: View {
    
    let gameBrain = GameBrain.shared
    
    var body: some View {
        
        VStack{
            List{
                ForEach (gameBrain.questionList, id: \.self){ question in
                                    NavigationLink(question.question, destination: QuestionDetails(question: question))
                                }
            }
        
        }
    }
}

#Preview {
    QuestionList()
}
