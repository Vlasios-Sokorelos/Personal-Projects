//
//  ButtonGrid.swift
//  quizSwiftUI
//
//  Created by ΒΛΑΣΗΣ ΣΟΚΟΡΕΛΟΣ on 8/6/24.
//

import SwiftUI

struct ButtonGrid: View {
    @Binding var selectedAnswer: String?
    @Binding var isCorrectAnswer: Bool?
    @Binding var correctAnswer: String?
    let checkAnswer: (String) -> Void
    
    let buttons = ["A", "B", "C", "D"] // Add more buttons if needed
    
    var body: some View {
        VStack(spacing: 10) {
            ForEach(0..<2) { row in
                HStack(spacing: 10) {
                    ForEach(0..<2) { column in
                        let index = row * 2 + column
                        if index < self.buttons.count {
                            let buttonLabel = self.buttons[index]
                            Button(action: {
                                
                                    self.checkAnswer(buttonLabel)
                                
                            }) {
                                Text(buttonLabel)
                                    .padding()
                                    .customButtonStyle(isSelected: self.selectedAnswer == buttonLabel,
                                                       isCorrect: self.isCorrectAnswer == true,
                                                       isCurrentAnswer: self.correctAnswer == buttonLabel)
                            }
                        } else {
                            Spacer()
                        }
                    }
                }
            }
        }
    }
}

#Preview {
    ButtonGrid(selectedAnswer: .constant(""),
               isCorrectAnswer: .constant(false),
               correctAnswer: .constant(""),
               checkAnswer: { _ in })
}
