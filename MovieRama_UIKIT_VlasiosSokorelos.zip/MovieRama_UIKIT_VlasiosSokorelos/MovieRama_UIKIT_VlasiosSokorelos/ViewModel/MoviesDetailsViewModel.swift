//
//  MoviesDetailsViewModel.swift
//  MovieRama_UIKIT_VlasiosSokorelos
//
//  Created by ΒΛΑΣΗΣ ΣΟΚΟΡΕΛΟΣ on 19/12/24.
//

import Foundation
import UIKit

class MoviesDetailsViewModel {
    
    // MARK: - Properties
    private let movieDetailsService = MovieDetailsService()  // Service to fetch movie details
    
    var onUpdate: (() -> Void)? // Callback to notify the ViewController when data updates
    
    private(set) var title: String = ""
    private(set) var genres: String = ""
    private(set) var releaseDate: String = ""
    private(set) var rating: String = ""
    private(set) var director: String = ""
    private(set) var cast: String = ""
    private(set) var posterURL: URL? = nil
    private(set) var reviews: [Review] = [] // Store reviews
    private(set) var similarMovies: [Movie] = [] // Store similar movies
    private(set) var description: String = "" // Movie description
    
    // MARK: - Fetch Movie Details
    /// Fetches movie details by movieID and updates the ViewModel properties.
    /// - Parameter movieID: The ID of the movie to fetch details for.
    func fetchMovieDetails(movieID: Int) {
        movieDetailsService.fetchMovieDetails(movieId: movieID) { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success(let movieDetail):
                    self?.processMovieDetail(movieDetail) // Process the fetched movie details
                case .failure(let error):
                    self?.handleError(error) // Handle any error that occurs
                }
            }
        }
    }
    
    // MARK: - Process Movie Detail
    /// Processes the fetched movie details and updates the properties of the ViewModel.
    /// - Parameter movieDetail: The details of the movie fetched from the API.
    private func processMovieDetail(_ movieDetail: MovieDetail) {
        title = movieDetail.title
        
        // Join genres into a single string
        genres = movieDetail.genres.map { $0.name }.joined(separator: ", ")
        
        // Format and set the release date
        if let formattedReleaseDate = formatReleaseDate(movieDetail.releaseDate) {
            releaseDate = formattedReleaseDate
        }
        
        // Format and set the rating
        let formattedRating = String(format: "%.2f", movieDetail.rating)
        rating = "Rating: \(formattedRating)/10"
        
        // Set the director and cast
        director = "Director: \(movieDetail.director)"
        cast = movieDetail.cast.joined(separator: ", ")
        
        // Set the poster URL if available
        if let posterPath = movieDetail.posterPath {
            posterURL = URL(string: "https://image.tmdb.org/t/p/w500\(posterPath)")
        }
        
        // Set reviews and similar movies
        reviews = movieDetail.reviews ?? []
        similarMovies = movieDetail.similarMovies ?? []
        
        // Set the movie description
        description = movieDetail.overview
        
        onUpdate?() // Notify the ViewController to update the UI
    }
    
    // MARK: - Handle Errors
    /// Handles errors during the fetching of movie details.
    /// - Parameter error: The error encountered while fetching the movie details.
    private func handleError(_ error: Error) {
        // Handle the error (e.g., show an error message to the user)
        print("Error fetching movie details: \(error.localizedDescription)")
    }
    
    // MARK: - Download Movie Poster Image
    /// Downloads the movie poster image from the URL.
    /// - Parameter completion: A closure to return the image or nil if the download fails.
    func downloadImage(completion: @escaping (UIImage?) -> Void) {
        guard let posterURL = posterURL else {
            completion(nil) // Return nil if there is no poster URL
            return
        }
        
        // Download the image data asynchronously
        URLSession.shared.dataTask(with: posterURL) { data, _, _ in
            guard let data = data, let image = UIImage(data: data) else {
                completion(nil) // Return nil if the image download fails
                return
            }
            completion(image) // Return the downloaded image
        }.resume()
    }
    
    // MARK: - Format Release Date
    /// Formats the release date string from "yyyy-MM-dd" to "d MMMM yyyy" format.
    /// - Parameter dateString: The release date string in "yyyy-MM-dd" format.
    /// - Returns: The formatted release date string or nil if formatting fails.
    private func formatReleaseDate(_ dateString: String) -> String? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd" // Expected format for the release date
        
        if let date = dateFormatter.date(from: dateString) {
            // Format to "Day Month Year" (e.g., "19 December 2024")
            dateFormatter.dateFormat = "d MMMM yyyy"
            return dateFormatter.string(from: date)
        }
        
        return nil // Return nil if date format is incorrect
    }
}
