//
//  MoviesViewModel.swift
//  MovieRama_UIKIT_VlasiosSokorelos
//
//  Created by ΒΛΑΣΗΣ ΣΟΚΟΡΕΛΟΣ on 17/12/24.
//

import Foundation

class MoviesViewModel {
    
    // MARK: - Properties
    private let moviesService = MoviesService()  // Service to handle API calls
    private(set) var movies: [Movie] = [] // List of movies, kept private but accessible for updates
    private var currentPage = 1 // Current page for pagination
    public var isFetching = false // Flag to prevent duplicate requests
    
    var didUpdateMovies: (() -> Void)? // Closure to notify the ViewController when movies are updated
    
    // MARK: - Fetch Popular Movies
    /// Fetches the popular movies from the service and appends them to the current list.
    func fetchPopularMovies() {
        guard !isFetching else { return } // Prevent duplicate fetches
        isFetching = true
        
        moviesService.fetchPopularMovies(page: currentPage) { [weak self] (fetchedMovies, error) in
            guard let self = self else { return }
            self.isFetching = false
            
            if let error = error {
                print("Error fetching popular movies: \(error)")
                return
            }
            
            if let fetchedMovies = fetchedMovies {
                self.movies.append(contentsOf: fetchedMovies) // Append new data
                self.currentPage += 1 // Increment the page number for the next request
                DispatchQueue.main.async {
                    self.didUpdateMovies?() // Notify the ViewController
                }
            }
        }
    }
    
    // MARK: - Reset Movies
    /// Resets the movie list and current page, typically called for refresh or search actions.
    func resetMovies() {
        movies = [] // Clear the current list of movies
        currentPage = 1 // Reset to the first page
    }
    
    // MARK: - Search Movies
    /// Searches for movies by a given query and appends the results to the list.
    /// - Parameter query: The search query string.
    func searchMovies(query: String) {
        guard !isFetching else { return } // Prevent duplicate fetches
        isFetching = true
        
        // Reset search results before new search
        resetSearchResults(query: query)
        
        moviesService.searchMovies(query: query, page: currentPage) { [weak self] (fetchedMovies, error) in
            guard let self = self else { return }
            self.isFetching = false
            
            if let error = error {
                print("Error searching movies: \(error)")
                return
            }
            
            if let fetchedMovies = fetchedMovies {
                self.movies.append(contentsOf: fetchedMovies) // Append new data
                self.currentPage += 1 // Increment the page number for the next request
                DispatchQueue.main.async {
                    self.didUpdateMovies?() // Notify the ViewController
                }
            }
        }
    }
    
    // MARK: - Reset Search Results
    /// Resets the search results and prepares for a new search.
    /// - Parameter query: The query string that triggered the search reset.
    func resetSearchResults(query: String) {
        movies = [] // Clear existing search results
        currentPage = 1 // Reset to the first page
    }
    
    // MARK: - Fetch Favorite Movies
    /// Fetches the list of favorite movies and updates the movie list.
    func fetchFavoriteMovies() {
        guard !isFetching else { return } // Prevent duplicate fetches
        isFetching = true
        
        moviesService.fetchMoviesFromFavorites { [weak self] (movies, error) in
            DispatchQueue.main.async {
                guard let self = self else { return }
                
                if let error = error {
                    print("Error fetching favorite movies: \(error.localizedDescription)")
                    self.isFetching = false
                    return
                }
                
                // If favorite movies are fetched, assign them to the list, otherwise clear the list
                if let movies = movies, !movies.isEmpty {
                    self.movies = movies
                } else {
                    print("No favorite movies found.")
                    self.movies = [] // Clear if no favorite movies are found
                }
                
                self.isFetching = false
                self.didUpdateMovies?() // Notify the ViewController of updates
            }
        }
    }
    
    // MARK: - Helper Methods
    
    /// Returns the total number of movies in the list.
    /// - Returns: The number of movies.
    func numberOfMovies() -> Int {
        return movies.count
    }
    
    /// Returns the movie at the specified index.
    /// - Parameter index: The index of the movie in the list.
    /// - Returns: The movie at the specified index.
    func movie(at index: Int) -> Movie {
        return movies[index]
    }
}
