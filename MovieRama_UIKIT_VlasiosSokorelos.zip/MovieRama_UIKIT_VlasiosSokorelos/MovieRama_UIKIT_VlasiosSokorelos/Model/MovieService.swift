//
//  MovieService.swift
//  MovieRama_UIKIT_VlasiosSokorelos
//
//  Created by ΒΛΑΣΗΣ ΣΟΚΟΡΕΛΟΣ on 16/12/24.
//

import Foundation

// MARK: - MoviesService Class
/// Class responsible for handling movie-related functionalities such as fetching popular movies, searching movies, and fetching favorite movies.
class MoviesService {
    
    // MARK: - Properties
    /// API key for The Movie Database (TMDB)
    private let apiKey = "30842f7c80f80bb3ad8a2fb98195544d"
    
    /// Base URL for fetching popular movies
    private let baseURL = "https://api.themoviedb.org/3/movie/popular"
    
    /// Base URL for searching movies
    private let searchBaseURL = "https://api.themoviedb.org/3/search/movie"
    
    /// Base URL for fetching specific movie details
    private let specificMovie = "https://api.themoviedb.org/3/movie/"
    
    // MARK: - Fetch Popular Movies
    /// Fetches popular movies with pagination support.
    /// - Parameters:
    ///   - page: The page number to fetch.
    ///   - completion: Closure to handle the array of `Movie` objects or an error.
    func fetchPopularMovies(page: Int, completion: @escaping ([Movie]?, Error?) -> Void) {
        // Construct the URL for the API request
        guard let url = URL(string: "\(baseURL)?api_key=\(apiKey)&language=en-US&page=\(page)") else {
            print("Invalid URL")
            return
        }
        
        // Perform the network request
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                // Handle network errors
                completion(nil, error)
                return
            }
            
            guard let data = data else {
                // Handle missing data
                completion(nil, NSError(domain: "No data", code: 0, userInfo: nil))
                return
            }
            
            do {
                // Decode JSON response
                let decodedResponse = try JSONDecoder().decode(TMDBMovies.self, from: data)
                completion(decodedResponse.results, nil)
            } catch {
                // Handle decoding errors
                completion(nil, error)
            }
        }.resume()
    }
    
    // MARK: - Search Movies
    /// Searches for movies based on a query with pagination support.
    /// - Parameters:
    ///   - query: The search term.
    ///   - page: The page number to fetch.
    ///   - completion: Closure to handle the array of `Movie` objects or an error.
    func searchMovies(query: String, page: Int, completion: @escaping ([Movie]?, Error?) -> Void) {
        // Encode the query to make it URL safe
        let encodedQuery = query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        
        // Construct the URL for the search request
        guard let url = URL(string: "\(searchBaseURL)?api_key=\(apiKey)&query=\(encodedQuery)&language=en-US&page=\(page)") else {
            print("Invalid search URL")
            return
        }
        
        // Perform the network request
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                // Handle network errors
                completion(nil, error)
                return
            }
            
            guard let data = data else {
                // Handle missing data
                completion(nil, NSError(domain: "No data", code: 0, userInfo: nil))
                return
            }
            
            do {
                // Decode JSON response
                let decodedResponse = try JSONDecoder().decode(TMDBMovies.self, from: data)
                completion(decodedResponse.results, nil)
            } catch {
                // Handle decoding errors
                completion(nil, error)
            }
        }.resume()
    }
    
    // MARK: - Fetch Movies from Favorites
    /// Fetches movie details for the movies marked as favorites.
    /// - Parameter completion: Closure to handle the array of `Movie` objects or an error.
    func fetchMoviesFromFavorites(completion: @escaping ([Movie]?, Error?) -> Void) {
        // Retrieve favorite movie IDs from PersistentDataControls
        let movieDictionary = PersistentDataControls.shared.getMovieDictionary()
        let favoriteMovieIDs = movieDictionary.filter { $0.value == true }.map { $0.key }
        
        // Use DispatchGroup to manage multiple network requests
        let dispatchGroup = DispatchGroup()
        var fetchedMovies: [Movie] = []
        var fetchError: Error?
        
        for movieID in favoriteMovieIDs {
            dispatchGroup.enter()
            
            // Construct the URL for the specific movie
            guard let url = URL(string: "\(specificMovie)\(movieID)?api_key=\(apiKey)&language=en-US") else {
                print("Invalid URL for movie ID: \(movieID)")
                dispatchGroup.leave()
                continue
            }
            
            // Perform the network request for each movie
            URLSession.shared.dataTask(with: url) { data, response, error in
                if let error = error {
                    fetchError = error
                    dispatchGroup.leave()
                    return
                }
                
                guard let data = data else {
                    fetchError = NSError(domain: "No data", code: 0, userInfo: nil)
                    dispatchGroup.leave()
                    return
                }
                
                do {
                    // Decode JSON response
                    let movie = try JSONDecoder().decode(Movie.self, from: data)
                    fetchedMovies.append(movie)
                } catch {
                    fetchError = error
                }
                
                dispatchGroup.leave()
            }.resume()
        }
        
        // Notify completion once all requests are finished
        dispatchGroup.notify(queue: .main) {
            if let error = fetchError {
                completion(nil, error)
            } else {
                completion(fetchedMovies, nil)
            }
        }
    }
}

