//
//  MovieDetailsService.swift
//  MovieRama_UIKIT_VlasiosSokorelos
//
//  Created by ΒΛΑΣΗΣ ΣΟΚΟΡΕΛΟΣ on 18/12/24.
//

import Foundation

// MARK: - MovieDetailsService Class
/// Service responsible for fetching detailed information about movies, including credits, similar movies, and reviews.
class MovieDetailsService {
    
    // MARK: - Properties
    private let baseURL = "https://api.themoviedb.org/3"
    private let apiKey = "30842f7c80f80bb3ad8a2fb98195544d"
    private let urlSession: URLSession = .shared
    
    // MARK: - Public Methods
    
    /// Fetches detailed information about a movie, including credits, similar movies, and reviews.
    /// - Parameters:
    ///   - movieId: The ID of the movie.
    ///   - completion: Completion handler returning a `Result` with `MovieDetail` or an `Error`.
    func fetchMovieDetails(movieId: Int, completion: @escaping (Result<MovieDetail, Error>) -> Void) {
        let group = DispatchGroup()
        var movieDetail: MovieDetail?
        var similarMovies: [Movie] = []
        var reviews: [Review] = []
        var fetchError: Error?
        
        // URLs
        let detailURL = URL(string: "\(baseURL)/movie/\(movieId)?api_key=\(apiKey)&append_to_response=credits")!
        let similarMoviesURL = URL(string: "\(baseURL)/movie/\(movieId)/similar?api_key=\(apiKey)")!
        let reviewsURL = URL(string: "\(baseURL)/movie/\(movieId)/reviews?api_key=\(apiKey)")!
        
        // Fetch movie details
        group.enter()
        fetchMovieDetail(from: detailURL, movieId: movieId) { result in
            switch result {
            case .success(var detail):
                detail.populateAdditionalFields()
                movieDetail = detail
            case .failure(let error):
                fetchError = error
            }
            group.leave()
        }
        
        // Fetch similar movies
        group.enter()
        fetchSimilarMovies(from: similarMoviesURL) { result in
            if case .success(let movies) = result {
                similarMovies = movies
            }
            group.leave()
        }
        
        // Fetch reviews
        group.enter()
        fetchReviews(from: reviewsURL) { result in
            if case .success(let fetchedReviews) = result {
                reviews = fetchedReviews
            }
            group.leave()
        }
        
        // Completion after all requests finish
        group.notify(queue: .main) {
            if let error = fetchError {
                completion(.failure(error))
            } else if var detail = movieDetail {
                detail.similarMovies = similarMovies
                detail.reviews = reviews
                completion(.success(detail))
            }
        }
    }
    
    // MARK: - Private Methods
    
    /// Fetches the main movie details and updates it with credits information.
    private func fetchMovieDetail(from url: URL, movieId: Int, completion: @escaping (Result<MovieDetail, Error>) -> Void) {
        urlSession.dataTask(with: url) { data, _, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            
            guard let data = data else {
                completion(.failure(NSError(domain: "NoData", code: 0, userInfo: [NSLocalizedDescriptionKey: "Data is missing."])))
                return
            }
            
            do {
                var movieDetail = try JSONDecoder().decode(MovieDetail.self, from: data)
                self.fetchCredits(forMovieId: movieId) { result in
                    switch result {
                    case .success(let credits):
                        movieDetail.credits = credits
                        movieDetail.populateAdditionalFields()
                        completion(.success(movieDetail))
                    case .failure(let error):
                        completion(.failure(error))
                    }
                }
            } catch {
                completion(.failure(error))
            }
        }.resume()
    }
    
    /// Fetches credits for the given movie ID.
    private func fetchCredits(forMovieId movieId: Int, completion: @escaping (Result<MovieDetail.Credits, Error>) -> Void) {
        let creditsURL = URL(string: "\(baseURL)/movie/\(movieId)/credits?api_key=\(apiKey)")!
        urlSession.dataTask(with: creditsURL) { data, _, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            
            guard let data = data else {
                completion(.failure(NSError(domain: "NoData", code: 0, userInfo: [NSLocalizedDescriptionKey: "Credits data is missing."])))
                return
            }
            
            do {
                let credits = try JSONDecoder().decode(MovieDetail.Credits.self, from: data)
                completion(.success(credits))
            } catch {
                completion(.failure(error))
            }
        }.resume()
    }
    
    /// Fetches similar movies.
    private func fetchSimilarMovies(from url: URL, completion: @escaping (Result<[Movie], Error>) -> Void) {
        urlSession.dataTask(with: url) { data, _, error in
            if let error = error {
                print("Failed to fetch similar movies: \(error.localizedDescription)")
                completion(.success([]))
                return
            }
            
            guard let data = data else {
                completion(.success([]))
                return
            }
            
            do {
                let response = try JSONDecoder().decode(SimilarMoviesResponse.self, from: data)
                completion(.success(response.results))
            } catch {
                completion(.success([]))
            }
        }.resume()
    }
    
    /// Fetches reviews for the movie.
    private func fetchReviews(from url: URL, completion: @escaping (Result<[Review], Error>) -> Void) {
        urlSession.dataTask(with: url) { data, _, error in
            if let error = error {
                print("Failed to fetch reviews: \(error.localizedDescription)")
                completion(.success([]))
                return
            }
            
            guard let data = data else {
                completion(.success([]))
                return
            }
            
            do {
                let response = try JSONDecoder().decode(ReviewsResponse.self, from: data)
                completion(.success(response.results))
            } catch {
                completion(.success([]))
            }
        }.resume()
    }
}


