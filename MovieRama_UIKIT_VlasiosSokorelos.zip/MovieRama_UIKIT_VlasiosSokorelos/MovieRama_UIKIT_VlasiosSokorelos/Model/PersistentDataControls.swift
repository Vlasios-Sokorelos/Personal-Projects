//
//  PersistentDataControls.swift
//  MovieRama_UIKIT_VlasiosSokorelos
//
//  Created by ΒΛΑΣΗΣ ΣΟΚΟΡΕΛΟΣ on 18/12/24.
//

import Foundation

/// Manages persistent data such as movie favorite statuses and theme preferences using `UserDefaults`.
class PersistentDataControls {
    
    // MARK: - Singleton Instance
    static let shared = PersistentDataControls()
    
    private let defaults = UserDefaults.standard
    
    // Keys for storing data in UserDefaults
    private let movieStatusKey = "movieStatusDictionary"
    private let themePreferenceKey = "themePreference"
    
    // Prevent direct initialization
    private init() {}
    
    // MARK: - Movie Status Management
    
    /// Retrieves the dictionary of movie favorite statuses from UserDefaults.
    /// - Returns: A dictionary with movie IDs as keys and their favorite status (`true`/`false`) as values.
    public func getMovieDictionary() -> [String: Bool] {
        return defaults.dictionary(forKey: movieStatusKey) as? [String: Bool] ?? [:]
    }
    
    /// Saves the dictionary of movie favorite statuses to UserDefaults.
    /// - Parameter dictionary: The dictionary to be saved.
    private func saveMovieDictionary(_ dictionary: [String: Bool]) {
        defaults.set(dictionary, forKey: movieStatusKey)
    }
    
    /// Checks if a movie ID exists in the favorite status dictionary.
    /// - Parameter movieID: The movie ID to check.
    /// - Returns: `true` if the movie ID exists, `false` otherwise.
    func movieExists(_ movieID: String) -> Bool {
        let movieDictionary = getMovieDictionary()
        return movieDictionary[movieID] != nil
    }
    
    /// Sets the favorite status for a specific movie ID.
    /// - Parameters:
    ///   - movieID: The movie ID to update.
    ///   - status: The favorite status to set (`true` for favorite, `false` for not favorite).
    func setMovieStatus(for movieID: String, to status: Bool) {
        var movieDictionary = getMovieDictionary()
        movieDictionary[movieID] = status
        saveMovieDictionary(movieDictionary)
    }
    
    /// Gets the favorite status for a specific movie ID.
    /// - Parameter movieID: The movie ID to retrieve the status for.
    /// - Returns: The favorite status (`true`/`false`), or `nil` if the movie ID doesn't exist.
    func getMovieStatus(for movieID: String) -> Bool? {
        let movieDictionary = getMovieDictionary()
        return movieDictionary[movieID]
    }
    
    /// Removes a movie ID from the favorite status dictionary.
    /// - Parameter movieID: The movie ID to remove.
    func removeMovie(with movieID: String) {
        var movieDictionary = getMovieDictionary()
        movieDictionary.removeValue(forKey: movieID)
        saveMovieDictionary(movieDictionary)
    }
    
    /// Prints all movie IDs and their favorite statuses in the dictionary.
    func printMovieDictionary() {
        let movieDictionary = getMovieDictionary()
        for (movieID, status) in movieDictionary {
            print("Movie ID: \(movieID), Favorite Status: \(status)")
        }
    }
    
    // MARK: - Theme Preference Management
    
    /// Retrieves the current theme preference.
    /// - Returns: The theme preference as a string (`"light"` or `"dark"`). Defaults to `"light"` if not set.
    func getThemePreference() -> String {
        return defaults.string(forKey: themePreferenceKey) ?? "light"
    }
    
    /// Sets the theme preference.
    /// - Parameter theme: The theme to set (`"light"` or `"dark"`).
    func setThemePreference(_ theme: String) {
        defaults.set(theme, forKey: themePreferenceKey)
    }
}
