//
//  Extensions.swift
//  MovieRama_UIKIT_VlasiosSokorelos
//
//  Created by ΒΛΑΣΗΣ ΣΟΚΟΡΕΛΟΣ on 17/12/24.
//


import Foundation
import UIKit

// MARK: - UIImageView Extension
extension UIImageView {
    /// Asynchronously loads an image from a URL with an optional placeholder.
    /// - Parameters:
    ///   - url: The URL to load the image from.
    ///   - placeholder: A placeholder image displayed while the image is being loaded.
    func loadImage(from url: URL?, placeholder: UIImage? = nil) {
        guard let url = url else {
            self.image = placeholder
            return
        }
        
        self.image = placeholder
        
        URLSession.shared.dataTask(with: url) { data, _, _ in
            if let data = data, let image = UIImage(data: data) {
                DispatchQueue.main.async {
                    self.image = image
                }
            }
        }.resume()
    }
}

// MARK: - UITableView Infinite Scrolling Extension
extension UITableView {
    /// Adds infinite scrolling functionality to the table view.
    /// - Parameter action: A closure triggered when the bottom of the table view is reached.
    func addInfiniteScrolling(action: @escaping () -> Void) {
        let scrollView = self as UIScrollView
        
        // Remove existing infinite scrolling view if any
        if let existingView = objc_getAssociatedObject(self, &AssociatedKeys.infiniteScrollingViewKey) as? InfiniteScrollingView {
            existingView.removeFromSuperview()
        }
        
        // Create and add the infinite scrolling view
        let infiniteScrollingView = InfiniteScrollingView(frame: CGRect(x: 0, y: self.contentSize.height, width: self.frame.width, height: 60))
        infiniteScrollingView.action = action
        self.addSubview(infiniteScrollingView)
        
        // Store the infinite scrolling view
        objc_setAssociatedObject(self, &AssociatedKeys.infiniteScrollingViewKey, infiniteScrollingView, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)
        
        // Observe content offset changes
        scrollView.delegate = self
    }
    
    /// Stops the infinite scrolling animation.
    func stopInfiniteScrolling() {
        guard let infiniteScrollingView = objc_getAssociatedObject(self, &AssociatedKeys.infiniteScrollingViewKey) as? InfiniteScrollingView else {
            print("InfiniteScrollingView is not available.")
            return
        }
        infiniteScrollingView.stopAnimating()
    }
}

// MARK: - UITableView AssociatedKeys and InfiniteScrollingView
private extension UITableView {
    struct AssociatedKeys {
        static var infiniteScrollingViewKey = "infiniteScrollingViewKey"
    }
    
    class InfiniteScrollingView: UIView {
        var action: (() -> Void)?
        public var spinner: UIActivityIndicatorView!
        
        override init(frame: CGRect) {
            super.init(frame: frame)
            setupView()
        }
        
        required init?(coder: NSCoder) {
            super.init(coder: coder)
            setupView()
        }
        
        private func setupView() {
            spinner = UIActivityIndicatorView(style: .medium)
            spinner.center = CGPoint(x: self.bounds.midX, y: self.bounds.midY)
            addSubview(spinner)
        }
        
        func startAnimating() {
            spinner.startAnimating()
        }
        
        func stopAnimating() {
            spinner.stopAnimating()
        }
    }
}

// MARK: - UITableView UIScrollViewDelegate
extension UITableView: UIScrollViewDelegate {
    public func scrollViewDidScroll(_ scrollView: UIScrollView) {
        guard let infiniteScrollingView = objc_getAssociatedObject(self, &AssociatedKeys.infiniteScrollingViewKey) as? InfiniteScrollingView else {
            return
        }
        
        let contentHeight = scrollView.contentSize.height
        let contentOffsetY = scrollView.contentOffset.y
        let scrollViewHeight = scrollView.frame.height
        
        // Trigger infinite scrolling when near the bottom
        if contentOffsetY + scrollViewHeight > contentHeight + 40, !infiniteScrollingView.spinner.isAnimating {
            infiniteScrollingView.startAnimating()
            infiniteScrollingView.action?()
        }
    }
}

// MARK: - UITextFieldDelegate Extension
extension SearchMoviesViewController: UITextFieldDelegate {
    /// Handles the return key press on the keyboard, dismissing it.
    /// - Parameter textField: The active `UITextField`.
    /// - Returns: `true` if the text field should process the return key press.
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}

