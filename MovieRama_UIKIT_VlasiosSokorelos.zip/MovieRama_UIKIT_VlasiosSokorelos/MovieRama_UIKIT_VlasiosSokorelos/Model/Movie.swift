//
//  Movie.swift
//  MovieRama_UIKIT_VlasiosSokorelos
//
//  Created by ΒΛΑΣΗΣ ΣΟΚΟΡΕΛΟΣ on 16/12/24.
//

import Foundation

// MARK: - Movie Struct
/// Struct representing a Movie item received from an API call.
struct Movie: Decodable {
    
    // MARK: - Properties
    /// Constant values as per Home-Screen - Popular requirements
    let id: Int
    let posterPath: String?
    let title: String
    let releaseDate: String
    let rating: Double
    
    /// Variable value to track the user's favorite status
    var favouriteStatus: Bool = false
    
    // MARK: - CodingKeys Enum
    /// Keys needed to map the API response to model properties.
    enum CodingKeys: String, CodingKey {
        case id
        case posterPath = "poster_path"
        case title
        case releaseDate = "release_date"
        case rating = "vote_average"
    }
}

// MARK: - TMDBMovies Struct
/// Struct responsible for holding the result from an API call for movies.
struct TMDBMovies: Decodable {
    
    // MARK: - Properties
    /// Array of `Movie` objects as returned by the API.
    /// Declared as a variable to support updates during fetch operations.
    var results: [Movie]
}

