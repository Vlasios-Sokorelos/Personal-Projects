//
//  MovieDetails.swift
//  MovieRama_UIKIT_VlasiosSokorelos
//
//  Created by ΒΛΑΣΗΣ ΣΟΚΟΡΕΛΟΣ on 18/12/24.
//

import Foundation

// MARK: - MovieDetail Struct
/// Struct representing detailed information about a movie, including credits, genres, similar movies, and reviews.
struct MovieDetail: Decodable {
    
    // MARK: - Properties
    /// Basic movie details
    let id: Int  // Unique identifier for the movie
    let title: String  // Movie title
    let posterPath: String?  // URL path for the poster image
    let overview: String  // Brief description of the movie
    let genres: [Genre]  // List of genres associated with the movie
    var credits: Credits  // Information about the cast and crew
    let releaseDate: String  // Release date in "YYYY-MM-DD" format
    let rating: Double  // Average user rating
    var similarMovies: [Movie]?  // List of similar movies (optional)
    var reviews: [Review]?  // List of reviews (optional)
    
    /// Additional properties for user preferences and extracted details
    var favouriteStatus: Bool = false  // Indicates if the movie is marked as a favorite
    var director: String = ""  // Director's name, extracted from credits
    var cast: [String] = []  // List of cast member names, extracted from credits
    
    // MARK: - CodingKeys
    /// Enum defining the keys used to map API values to model properties
    enum CodingKeys: String, CodingKey {
        case id
        case title
        case posterPath = "poster_path"
        case overview
        case genres
        case releaseDate = "release_date"
        case rating = "vote_average"
        case similarMovies = "similar"
        case reviews
        case credits
    }
    
    // MARK: - Nested Credits Struct
    /// Struct representing the credits information of a movie.
    struct Credits: Decodable {
        let cast: [CastMember]  // List of cast members
        let crew: [CrewMember]  // List of crew members
        
        // MARK: - Nested CastMember Struct
        /// Struct representing a cast member.
        struct CastMember: Decodable {
            let name: String  // Name of the cast member
        }
        
        // MARK: - Nested CrewMember Struct
        /// Struct representing a crew member.
        struct CrewMember: Decodable {
            let name: String  // Name of the crew member
            let job: String  // Job role of the crew member
        }
    }
    
    // MARK: - Helper Methods
    /// Populates additional fields such as director and cast from the credits.
    mutating func populateAdditionalFields() {
        // Extract the director from the crew
        if let directorCrewMember = credits.crew.first(where: { $0.job == "Director" }) {
            self.director = directorCrewMember.name
        }
        
        // Extract cast names
        self.cast = credits.cast.map { $0.name }
    }
}

// MARK: - Genre Struct
/// Struct representing a genre associated with a movie.
struct Genre: Decodable {
    let name: String  // Name of the genre
}

// MARK: - Review Struct
/// Struct representing a review of a movie.
struct Review: Decodable {
    let author: String  // Name of the review's author
    let content: String  // Content of the review
}

// MARK: - SimilarMoviesResponse Struct
/// Struct representing the response for a similar movies API call.
struct SimilarMoviesResponse: Decodable {
    let results: [Movie]  // List of similar movies
}

// MARK: - ReviewsResponse Struct
/// Struct representing the response for a reviews API call.
struct ReviewsResponse: Decodable {
    let results: [Review]  // List of reviews
}
