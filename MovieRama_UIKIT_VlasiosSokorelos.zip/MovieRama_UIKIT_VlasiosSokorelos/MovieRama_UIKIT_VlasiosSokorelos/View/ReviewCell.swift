//
//  ReviewCell.swift
//  MovieRama_UIKIT_VlasiosSokorelos
//
//  Created by ΒΛΑΣΗΣ ΣΟΚΟΡΕΛΟΣ on 19/12/24.
//

import UIKit

class ReviewCell: UITableViewCell {
    
    // MARK: - Outlets
    @IBOutlet weak var reviewAuthor: UILabel!  // Label to display the name of the review's author
    @IBOutlet weak var reviewText: UILabel!    // Label to display the content of the review
    
    // MARK: - Initialization
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code can be placed here
        // Any additional setup for the cell goes here
    }
    
    
    
}
