//
//  MovieCell.swift
//  MovieRama_UIKIT_VlasiosSokorelos
//
//  Created by ΒΛΑΣΗΣ ΣΟΚΟΡΕΛΟΣ on 16/12/24.
//

import UIKit

class MovieCell: UITableViewCell {
    
    // MARK: - Outlets
    @IBOutlet weak var moviePoster: UIImageView!
    @IBOutlet weak var movieTitle: UILabel!
    @IBOutlet weak var movieReleaseDate: UILabel!
    @IBOutlet weak var movieRating: UILabel!
    @IBOutlet weak var movieFavouriteStatus: UIButton!
    
    // MARK: - Properties
    private var movieID: Int?
    var onFavoriteTapped: (() -> Void)?  // Closure to notify when the favorite button is tapped
    
    // MARK: - Initialization
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    // MARK: - Configuration
    /// Configures the cell with a `Movie` object.
    /// - Parameter movie: The movie to display in the cell.
    func configure(with movie: Movie) {
        movieID = movie.id
        movieTitle.text = movie.title
        
        if let formattedReleaseDate = formatReleaseDate(movie.releaseDate) {
            movieReleaseDate.text = formattedReleaseDate
        } else {
            movieReleaseDate.text = "Release Date: N/A"
        }
        
        let formattedRating = String(format: "%.2f", movie.rating)
        movieRating.text = "Rating: \(formattedRating)/10"
        
        if let posterPath = movie.posterPath {
            let posterURL = URL(string: "https://image.tmdb.org/t/p/w500\(posterPath)")
            moviePoster.loadImage(from: posterURL, placeholder: UIImage(systemName: "photo"))
        } else {
            moviePoster.image = UIImage(systemName: "photo")
        }
        
        updateFavoriteButtonState()
    }
    
    // MARK: - Actions
    /// Handles the favorite button tap.
    @IBAction func movieFavouriteButtonPressed(_ sender: UIButton) {
        favoriteButtonTapped()
    }
    
    @objc private func favoriteButtonTapped() {
        // Simulate a success/failure action with a random outcome
        let isSuccess = Bool.random()
        if !isSuccess {
            showToast(message: "Action Failed. Please try again.")
            return
        }
        
        guard let movieID = movieID else { return }
        let movieKey = String(movieID)
        
        // Update favorite status in persistent storage
        if PersistentDataControls.shared.movieExists(movieKey) {
            PersistentDataControls.shared.removeMovie(with: movieKey)
        } else {
            PersistentDataControls.shared.setMovieStatus(for: movieKey, to: true)
        }
        
        // Update the UI and notify the parent view controller
        updateFavoriteButtonState()
        onFavoriteTapped?()
    }
    
    // MARK: - Helpers
    /// Updates the favorite button's appearance based on the movie's status.
    private func updateFavoriteButtonState() {
        guard let movieID = movieID else { return }
        let isFavorite = PersistentDataControls.shared.movieExists(String(movieID))
        let buttonImage = isFavorite ? UIImage(systemName: "star.fill") : UIImage(systemName: "star")
        movieFavouriteStatus.setImage(buttonImage, for: .normal)
    }
    
    /// Formats a release date string from `yyyy-MM-dd` to `d MMMM yyyy`.
    /// - Parameter dateString: The release date as a string.
    /// - Returns: A formatted date string or `nil` if formatting fails.
    private func formatReleaseDate(_ dateString: String) -> String? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        if let date = dateFormatter.date(from: dateString) {
            dateFormatter.dateFormat = "d MMMM yyyy"
            return dateFormatter.string(from: date)
        }
        return nil
    }
    
    /// Displays a toast message on the cell.
    /// - Parameter message: The message to display.
    private func showToast(message: String) {
        let toastLabel = UILabel()
        toastLabel.text = message
        toastLabel.textColor = .white
        toastLabel.backgroundColor = .black.withAlphaComponent(0.7)
        toastLabel.textAlignment = .center
        toastLabel.alpha = 1.0
        toastLabel.layer.cornerRadius = 10
        toastLabel.clipsToBounds = true
        toastLabel.numberOfLines = 0
        toastLabel.frame = CGRect(
            x: 20,
            y: self.contentView.frame.size.height - 60,
            width: self.contentView.frame.size.width - 40,
            height: 40
        )
        
        self.contentView.addSubview(toastLabel)
        
        UIView.animate(withDuration: 2.5, delay: 0.1, options: .curveEaseOut, animations: {
            toastLabel.alpha = 0.0
        }, completion: { _ in
            toastLabel.removeFromSuperview()
        })
    }
}
