//
//  FavouriteMoviesScreen.swift
//  MovieRama_UIKIT_VlasiosSokorelos
//
//  Created by ΒΛΑΣΗΣ ΣΟΚΟΡΕΛΟΣ on 19/12/24.
//

import UIKit

class FavouriteMoviesScreen: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    // MARK: - Outlets
    @IBOutlet weak var favouriteMoviesTable: UITableView! // Table view for displaying favorite movies
    
    // MARK: - Properties
    private var viewModel = MoviesViewModel() // ViewModel for managing movie data
    private let refreshControl = UIRefreshControl() // Pull-to-refresh control
    
    // MARK: - Lifecycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set the table view delegate and data source
        favouriteMoviesTable.delegate = self
        favouriteMoviesTable.dataSource = self
        
        // Register the custom MovieCell NIB
        let movieCellNib = UINib(nibName: "MovieCell", bundle: nil)
        favouriteMoviesTable.register(movieCellNib, forCellReuseIdentifier: "movieCell")
        
        // Set up the pull-to-refresh control
        favouriteMoviesTable.refreshControl = refreshControl
        refreshControl.addTarget(self, action: #selector(refreshMovies), for: .valueChanged)
        
        // Bind the data update closure to reload the table view when data is fetched
        viewModel.didUpdateMovies = { [weak self] in
            self?.favouriteMoviesTable.reloadData() // Reload table view after movies are updated
            self?.refreshControl.endRefreshing() // End refresh animation
        }
        
        // Fetch the favorite movies initially
        viewModel.fetchFavoriteMovies()
    }
    
    // MARK: - UITableViewDelegate & UITableViewDataSource Methods
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.numberOfMovies() // Return the number of movies in the ViewModel
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // Dequeue the custom MovieCell
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "movieCell", for: indexPath) as? MovieCell else {
            return UITableViewCell() // Return an empty cell in case of failure
        }
        
        // Get the movie at the current index from the ViewModel
        let movie = viewModel.movie(at: indexPath.row)
        
        // Configure the cell with movie data
        cell.configure(with: movie)
        
        // Set up the closure to handle the favorite button press
        cell.onFavoriteTapped = { [weak self] in
            // Refresh the favorite movies list when the favorite button is tapped
            self?.viewModel.fetchFavoriteMovies()  // Re-fetch the favorite movies
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        // Trigger segue to the movie details screen
        performSegue(withIdentifier: "favouriteMovieTransfer", sender: indexPath)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "favouriteMovieTransfer",
           let indexPath = sender as? IndexPath,
           let destinationVC = segue.destination as? MovieDetailsScreen {
            
            // Pass the movie ID to the destination view controller
            let selectedMovie = viewModel.movie(at: indexPath.row)
            destinationVC.movieID = selectedMovie.id
        }
    }
    
    // MARK: - Pull-to-Refresh Action
    @objc private func refreshMovies() {
        // Fetch the latest favorite movies and refresh the list
        viewModel.fetchFavoriteMovies()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // Refresh the favorite movies list when the view appears
        viewModel.fetchFavoriteMovies()
        favouriteMoviesTable.reloadData()
    }
}
