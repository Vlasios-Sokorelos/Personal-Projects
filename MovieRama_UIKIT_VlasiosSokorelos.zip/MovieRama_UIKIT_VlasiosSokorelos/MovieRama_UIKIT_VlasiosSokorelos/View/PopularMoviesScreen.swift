//
//  ViewController.swift
//  MovieRama_UIKIT_VlasiosSokorelos
//
//  Created by ΒΛΑΣΗΣ ΣΟΚΟΡΕΛΟΣ on 16/12/24.
//
import UIKit

class PopularMoviesScreen: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    // MARK: - Outlets
    @IBOutlet weak var movieTableView: UITableView! // Table view to display movies
    
    // MARK: - Properties
    private let viewModel = MoviesViewModel() // ViewModel for managing movie data
    private let refreshControl = UIRefreshControl() // Pull-to-refresh control
    
    // MARK: - Lifecycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        setupTableView() // Setup table view properties
        bindViewModel()  // Bind ViewModel data updates to the UI
        viewModel.fetchPopularMovies() // Fetch initial set of popular movies
    }
    
    // MARK: - TableView Setup
    private func setupTableView() {
        // Register movie cell nib
        let cellNib = UINib(nibName: "MovieCell", bundle: nil)
        movieTableView.register(cellNib, forCellReuseIdentifier: "movieCell")
        
        // Set delegate and dataSource for the table view
        movieTableView.delegate = self
        movieTableView.dataSource = self
        
        // Add Pull-to-Refresh functionality
        movieTableView.refreshControl = refreshControl
        refreshControl.addTarget(self, action: #selector(refreshMovies), for: .valueChanged)
    }
    
    // MARK: - ViewModel Binding
    private func bindViewModel() {
        viewModel.didUpdateMovies = { [weak self] in
            DispatchQueue.main.async {
                self?.movieTableView.reloadData() // Reload table when data updates
                self?.refreshControl.endRefreshing() // End refreshing after data loads
            }
        }
    }
    
    // MARK: - Pull-to-Refresh Action
    @objc private func refreshMovies() {
        viewModel.resetMovies() // Clear current data and reset to page 1
        viewModel.fetchPopularMovies() // Fetch fresh data
    }
    
    // MARK: - TableView DataSource and Delegate Methods
    
    // Return the number of rows (movies) in the table view
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.numberOfMovies() // Use ViewModel to get the movie count
    }
    
    // Configure and return the cell for a given index path
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let movieCell = movieTableView.dequeueReusableCell(withIdentifier: "movieCell", for: indexPath) as! MovieCell
        let movie = viewModel.movie(at: indexPath.row) // Get the movie from the ViewModel
        
        movieCell.configure(with: movie) // Configure the cell with movie data
        movieCell.onFavoriteTapped = { [weak self] in
            // Reload the table view to reflect the updated favorite status
            self?.movieTableView.reloadData()
        }
        
        return movieCell
    }
    
    // MARK: - Infinite Scrolling
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let position = scrollView.contentOffset.y
        let contentHeight = scrollView.contentSize.height
        let scrollHeight = scrollView.frame.size.height
        
        // Trigger infinite scroll when the user scrolls near the bottom
        if position > contentHeight - scrollHeight - 100 {
            viewModel.fetchPopularMovies() // Fetch more movies
        }
    }
    
    // MARK: - Movie Selection
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        // Trigger segue to movie details screen
        performSegue(withIdentifier: "popularMovieTransfer", sender: indexPath)
    }
    
    // MARK: - Prepare for Segue
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "popularMovieTransfer",
           let indexPath = sender as? IndexPath,
           let destinationVC = segue.destination as? MovieDetailsScreen {
            
            // Pass the selected movie ID to the destination view controller
            let selectedMovie = viewModel.movie(at: indexPath.row)
            destinationVC.movieID = selectedMovie.id
        }
    }
    
    // MARK: - View Will Appear
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // Reload the movies list to reflect updated favorite status
        viewModel.fetchPopularMovies()
        movieTableView.reloadData()
    }
}
