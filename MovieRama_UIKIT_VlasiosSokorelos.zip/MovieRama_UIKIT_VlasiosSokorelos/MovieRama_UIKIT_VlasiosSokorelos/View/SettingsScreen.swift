//
//  SettingsScreen.swift
//  MovieRama_UIKIT_VlasiosSokorelos
//
//  Created by ΒΛΑΣΗΣ ΣΟΚΟΡΕΛΟΣ on 19/12/24.
//

import UIKit

class SettingsScreen: UIViewController {
    
    // MARK: - Outlets
    @IBOutlet weak var themeLabelText: UILabel!
    
    // MARK: - View Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Fetch current theme preference from persistent storage
        let currentTheme = PersistentDataControls.shared.getThemePreference()
        
        // Update the theme label text to display the current theme
        themeLabelText.text = "Theme Control ---- Current Theme: \(currentTheme.capitalized)"
    }
    
    // MARK: - Actions
    
    @IBAction func toggleThemeButton(_ sender: UIButton) {
        print("test?")
        
        // Get the current theme preference from persistent storage
        let currentTheme = PersistentDataControls.shared.getThemePreference()
        
        // Print current theme to the console (for debugging)
        print(currentTheme)
        
        // Toggle between dark and light theme based on the current theme
        if currentTheme == "dark" {
            // Change to light theme
            themeLabelText.text = "Theme Control ---- Current Theme: LIGHT"
            PersistentDataControls.shared.setThemePreference("light")
            self.view.window?.overrideUserInterfaceStyle = .light
        } else {
            // Change to dark theme
            themeLabelText.text = "Theme Control ---- Current Theme: DARK"
            PersistentDataControls.shared.setThemePreference("dark")
            self.view.window?.overrideUserInterfaceStyle = .dark
        }
    }
}
