//
//  SearchMoviesScreen.swift
//  MovieRama_UIKIT_VlasiosSokorelos
//
//  Created by ΒΛΑΣΗΣ ΣΟΚΟΡΕΛΟΣ on 17/12/24.
//

import UIKit
class SearchMoviesViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    // MARK: - Outlets
    @IBOutlet weak var searchField: UITextField! // Search field for entering query
    @IBOutlet weak var movieSearchResults: UITableView! // TableView to display search results
    
    // MARK: - Properties
    var tapGesture: UITapGestureRecognizer? // Gesture to dismiss the keyboard
    private var searchQuery: String = "" // Store the current search query
    private var isLoading: Bool = false // Track loading state
    private let viewModel = MoviesViewModel() // ViewModel to manage movie data
    
    // MARK: - Lifecycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupTableView() // Set up table view properties
        searchField.delegate = self
        searchField.text = "" // Reset search field text
        viewModel.resetMovies() // Reset movies in the ViewModel
        
        // Bind ViewModel to update UI when data changes
        bindViewModel()
        
        // Set up infinite scrolling in the TableView
        movieSearchResults.addInfiniteScrolling {
            self.loadMoreMovies() // Load more movies when triggered
        }
        
        // Set TableView delegate and data source
        movieSearchResults.delegate = self
        movieSearchResults.dataSource = self
        
        // Listen for changes in the search text field
        searchField.addTarget(self, action: #selector(searchTextChanged), for: .editingChanged)
        
        // Keyboard notifications
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    // MARK: - TableView Setup
    private func setupTableView() {
        let cellNib = UINib(nibName: "MovieCell", bundle: nil) // Register MovieCell
        movieSearchResults.register(cellNib, forCellReuseIdentifier: "movieCell")
    }
    
    // MARK: - ViewModel Binding
    private func bindViewModel() {
        // Update the table view when the movies are updated
        viewModel.didUpdateMovies = { [weak self] in
            DispatchQueue.main.async {
                self?.movieSearchResults.reloadData() // Reload data in the table
                self?.movieSearchResults.stopInfiniteScrolling() // Stop infinite scrolling animation
            }
        }
    }
    
    // MARK: - Infinite Scrolling
    private func loadMoreMovies() {
        guard let query = searchField.text, !query.isEmpty else { return }
        
        // Prevent multiple requests if a fetch is in progress
        if !viewModel.isFetching {
            viewModel.searchMovies(query: query) // Fetch more movies for the search query
        }
    }
    
    // MARK: - Search Text Changes
    @objc private func searchTextChanged() {
        guard let query = searchField.text, query != searchQuery else { return }
        
        searchQuery = query // Update the search query
        viewModel.resetSearchResults(query: query) // Reset previous search results
        
        // Debugging log for the query being searched
        print("Starting search for query: \(query)")
        
        // Perform the search based on the new query
        viewModel.searchMovies(query: query)
    }
    
    // MARK: - TableView DataSource & Delegate Methods
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.numberOfMovies() // Return the number of movies from the ViewModel
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // Dequeue a reusable movie cell
        let movieCell = movieSearchResults.dequeueReusableCell(withIdentifier: "movieCell", for: indexPath) as! MovieCell
        
        // Get the movie object at the current index path
        let movie = viewModel.movie(at: indexPath.row)
        
        // Configure the cell with the movie data
        movieCell.configure(with: movie)
        
        // Handle favorite button tap
        movieCell.onFavoriteTapped = { [weak self] in
            self?.movieSearchResults.reloadData() // Reload the table view after updating favorites
        }
        
        return movieCell
    }
    
    // MARK: - Movie Selection
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        // Perform segue to the movie details screen when a movie is selected
        performSegue(withIdentifier: "searchMovieTransfer", sender: indexPath)
    }
    
    // MARK: - Prepare for Segue
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "searchMovieTransfer",
           let indexPath = sender as? IndexPath,
           let destinationVC = segue.destination as? MovieDetailsScreen {
            
            // Pass the selected movie ID to the destination screen
            let selectedMovie = viewModel.movie(at: indexPath.row)
            destinationVC.movieID = selectedMovie.id
        }
    }
    
    // MARK: - View Will Appear
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // If there is an active search query, refresh the results
        if !searchQuery.isEmpty {
            viewModel.searchMovies(query: searchQuery)
            movieSearchResults.reloadData()
        }
    }
    
    // MARK: - Keyboard Notifications
    @objc private func keyboardWillShow(notification: NSNotification) {
        if tapGesture == nil {
            // Add tap gesture to dismiss keyboard when tapped outside
            tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
            view.addGestureRecognizer(tapGesture!)
        }
    }
    
    @objc private func keyboardWillHide(notification: NSNotification) {
        // Remove the tap gesture when the keyboard hides
        if let gesture = tapGesture {
            view.removeGestureRecognizer(gesture)
            tapGesture = nil
        }
    }
    
    // MARK: - Dismiss Keyboard
    @objc private func dismissKeyboard() {
        view.endEditing(true) // Dismiss the keyboard
    }
    
    // MARK: - Deinit
    deinit {
        // Remove observers when the view is deallocated
        NotificationCenter.default.removeObserver(self)
    }
}
