//
//  SimilarMovieCell.swift
//  MovieRama_UIKIT_VlasiosSokorelos
//
//  Created by ΒΛΑΣΗΣ ΣΟΚΟΡΕΛΟΣ on 19/12/24.
//

import UIKit

class SimilarMovieCell: UICollectionViewCell {
    
    // MARK: - Outlets
    @IBOutlet weak var movieImage: UIImageView!  // Image view to display the movie poster
    @IBOutlet weak var movieTitle: UILabel!      // Label to display the movie title
    
    // MARK: - Initialization
    override func awakeFromNib() {
        super.awakeFromNib()
        // Any additional setup after loading the view can be done here
    }
    
}
