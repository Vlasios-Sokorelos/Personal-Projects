//
//  MovieDetailsScreen.swift
//  MovieRama_UIKIT_VlasiosSokorelos
//
//  Created by ΒΛΑΣΗΣ ΣΟΚΟΡΕΛΟΣ on 18/12/24.
//

import UIKit

class MovieDetailsScreen: UIViewController, UITableViewDelegate, UITableViewDataSource, UICollectionViewDataSource, UICollectionViewDelegate {
    
    
    // MARK: - Properties
    
    var movieID: Int? // Property to store the passed movie ID
    private let viewModel = MoviesDetailsViewModel() // ViewModel for managing movie details data
    
    // MARK: - Outlets
    @IBOutlet weak var moviePoster: UIImageView! // Outlet for the movie image
    @IBOutlet weak var movieTitle: UILabel! // Outlet for the movie title
    @IBOutlet weak var movieGenre: UILabel! // Outlet for the movie genres
    @IBOutlet weak var movieReleaseDate: UILabel! // Outlet for the movie release date
    @IBOutlet weak var movieRating: UILabel! // Outlet for the movie rating
    @IBOutlet weak var movieDirector: UILabel! // Outlet for the movie director name
    @IBOutlet weak var movieCastNames: UILabel! // Outlet for the movie cast names
    @IBOutlet weak var movieDescription: UILabel! // Outlet for the movie description text
    @IBOutlet weak var movieReviewsTable: UITableView! // Outlet for the movie reviews table
    @IBOutlet weak var similarMoviesCollectionView: UICollectionView! // Outlet for the similar movie collection
    @IBOutlet weak var movieFavouriteStatus: UIButton! // Outlet for the movie favourite button handling
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Setup for collection view
        setupCollectionView()
        
        // Setup for table view
        movieReviewsTable.delegate = self
        movieReviewsTable.dataSource = self
        
        // Bind view model updates to UI
        setupBindings()
        
        // Check if movieID is valid and fetch movie details
        if let movieID = movieID {
            viewModel.fetchMovieDetails(movieID: movieID)
        }
        
        // Register cell for reviews table
        let nib = UINib(nibName: "ReviewCell", bundle: nil)
        movieReviewsTable.register(nib, forCellReuseIdentifier: "reviewCell")
        
        // Update favorite button state
        updateFavoriteButtonState()
    }
    
    private func setupCollectionView() {
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = CGSize(width: 250, height: 166) // Adjust size as needed
        layout.scrollDirection = .horizontal
        similarMoviesCollectionView.collectionViewLayout = layout
        
        let nibCollection = UINib(nibName: "SimilarMovieCell", bundle: nil)
        similarMoviesCollectionView.register(nibCollection, forCellWithReuseIdentifier: "similarMovieCell")
        similarMoviesCollectionView.delegate = self
        similarMoviesCollectionView.dataSource = self
    }
    
    private func setupBindings() {
        viewModel.onUpdate = { [weak self] in
            self?.updateUI()
        }
    }
    
    private func updateUI() {
        movieTitle.text = viewModel.title
        movieGenre.text = viewModel.genres
        movieReleaseDate.text = viewModel.releaseDate
        movieRating.text = viewModel.rating
        movieDirector.text = viewModel.director
        movieCastNames.text = viewModel.cast
        movieDescription.text = viewModel.description
        
        movieReviewsTable.reloadData()
        similarMoviesCollectionView.reloadData()
        
        // Download the movie poster asynchronously
        viewModel.downloadImage { [weak self] image in
            DispatchQueue.main.async {
                self?.moviePoster.image = image
            }
        }
    }
    
    private func updateFavoriteButtonState() {
        guard let movieID = movieID else { return }
        
        let movieKey = String(movieID)
        let isFavorite = PersistentDataControls.shared.movieExists(movieKey)
        let buttonImage = isFavorite ? UIImage(systemName: "star.fill") : UIImage(systemName: "star")
        movieFavouriteStatus.setImage(buttonImage, for: .normal)
    }
    
    @IBAction func favoriteButtonTapped(_ sender: UIButton) {
        // Simulating a random success/failure for the operation
        let isSuccess = Bool.random()
        
        if !isSuccess {
            showToast(message: "Action Failed, try again")
            return
        }
        
        guard let movieID = movieID else { return }
        
        let movieKey = String(movieID)
        let isFavorite = PersistentDataControls.shared.movieExists(movieKey)
        
        // Toggle favorite status
        if isFavorite {
            PersistentDataControls.shared.removeMovie(with: movieKey)
        } else {
            PersistentDataControls.shared.setMovieStatus(for: movieKey, to: true)
        }
        
        // Update the favorite button state after the action
        updateFavoriteButtonState()
    }
    
    @IBAction func movieFavouriteButtonToggle(_ sender: UIButton) {
        favoriteButtonTapped(sender)
    }
    
    // MARK: - TableView DataSource and Delegate Methods
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.reviews.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "reviewCell", for: indexPath) as? ReviewCell else {
            return UITableViewCell()
        }
        
        let review = viewModel.reviews[indexPath.row]
        cell.reviewAuthor.text = review.author
        cell.reviewText.text = review.content
        
        return cell
    }
    
    // MARK: - CollectionView DataSource and Delegate Methods
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return viewModel.similarMovies.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "similarMovieCell", for: indexPath) as? SimilarMovieCell else {
            fatalError("Unable to dequeue CollectionViewCell")
        }
        
        let movie = viewModel.similarMovies[indexPath.item]
        cell.movieTitle.text = movie.title
        
        // Load movie poster asynchronously
        if let posterPath = movie.posterPath {
            let imageURL = URL(string: "https://image.tmdb.org/t/p/w500\(posterPath)")
            URLSession.shared.dataTask(with: imageURL!) { data, _, _ in
                if let data = data, let image = UIImage(data: data) {
                    DispatchQueue.main.async {
                        cell.movieImage.image = image
                    }
                }
            }.resume()
        } else {
            cell.movieImage.image = UIImage(named: "placeholder") // Use a placeholder image
        }
        
        return cell
    }
    
    // MARK: - Toast Message
    
    private func showToast(message: String) {
        let toastLabel = UILabel()
        toastLabel.text = message
        toastLabel.textColor = .white
        toastLabel.backgroundColor = .black
        toastLabel.textAlignment = .center
        toastLabel.alpha = 1.0
        toastLabel.layer.cornerRadius = 10
        toastLabel.clipsToBounds = true
        toastLabel.numberOfLines = 0
        
        let toastHeight: CGFloat = 50
        let verticalOffset: CGFloat = self.view.frame.size.height * 0.3 // 30% from the top
        toastLabel.frame = CGRect(x: 20, y: verticalOffset, width: self.view.frame.size.width - 40, height: toastHeight)
        
        self.view.addSubview(toastLabel)
        
        UIView.animate(withDuration: 3.0, delay: 0.1, options: .curveEaseOut, animations: {
            toastLabel.alpha = 0.0
        }, completion: { _ in
            toastLabel.removeFromSuperview()
        })
    }
}
