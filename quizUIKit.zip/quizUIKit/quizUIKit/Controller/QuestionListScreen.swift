//
//  QuestionListScreen.swift
//  quizUIKit
//
//  Created by ΒΛΑΣΗΣ ΣΟΚΟΡΕΛΟΣ on 8/6/24.
//

import UIKit

class QuestionListScreen: UIViewController {

    @IBOutlet weak var questionTable: UITableView!
    let gameBrain = GameBrain.shared
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        questionTable.delegate = self
        questionTable.dataSource = self
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            if segue.identifier == "showQuestionAnswer" {
                if let destinationVC = segue.destination as? QuestionDetailsScreen {
                    if let indexPath = questionTable.indexPathForSelectedRow {
                        destinationVC.selectedItem = indexPath.row
                        questionTable.deselectRow(at: indexPath, animated: true)
                    }
                }
            }
        }
   

}

extension QuestionListScreen: UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return gameBrain.questionList.count
    }
    
}


extension QuestionListScreen: UITableViewDataSource{
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = questionTable.dequeueReusableCell(withIdentifier: "questionCell", for: indexPath)
        
        cell.textLabel?.text = gameBrain.questionList[indexPath.row].question
        
        return cell
            
        
    }
    
    
    
    
}
