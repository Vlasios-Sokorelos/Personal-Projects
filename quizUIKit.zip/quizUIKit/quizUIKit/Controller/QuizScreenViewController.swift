//
//  QuizScreenViewController.swift
//  quizUIKit
//
//  Created by ΒΛΑΣΗΣ ΣΟΚΟΡΕΛΟΣ on 8/6/24.
//

import UIKit

class QuizScreenViewController: UIViewController {
    
    @IBOutlet weak var questionProgress: UILabel!
    
    @IBOutlet weak var questionText: UILabel!
    
    @IBOutlet weak var aButton: UIButton!
    
    @IBOutlet weak var bButton: UIButton!
    
    @IBOutlet weak var cButton: UIButton!
    
    @IBOutlet weak var dButton: UIButton!
    
   
    
    
    let gameBrain = GameBrain.shared
    
    override func viewDidLoad() {
        super.viewDidLoad()
        questionText.text = gameBrain.questionList[gameBrain.currentQuestion].question
        questionProgress.text = "Question \(gameBrain.currentQuestion+1) of \(gameBrain.questionList.count)"
    }
    
    
    @IBAction func userAnswer(_ sender: UIButton) {
        let buttonArray = [aButton,bButton,cButton,dButton]
        
        let test = (sender.titleLabel?.text)!
        if (gameBrain.correctAnswer(userAnswer: test)) {
            sender.backgroundColor = .green
            
        }
        else {
            sender.backgroundColor = .red
            for button in buttonArray{
                if (button?.titleLabel?.text == gameBrain.questionList[gameBrain.currentQuestion].answer){
                    button?.backgroundColor = .green                }
            }
        }
        for button in buttonArray{
            button?.isEnabled = false
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
            for button in buttonArray{
                button?.backgroundColor = nil
                button?.isEnabled = true
            }
            if (self.gameBrain.nextQuesiton()){
                self.questionText.text = self.gameBrain.questionList[self.gameBrain.currentQuestion].question
                self.questionProgress.text = "Question \(self.gameBrain.currentQuestion+1) of \(self.gameBrain.questionList.count)"
            }
            else{
                self.performSegue(withIdentifier: "showResults", sender: self)
                
            }
        }
    }
    
    @IBAction func unwindToQuizScreen(segue: UIStoryboardSegue) {
        gameBrain.currentQuestion = 0
        gameBrain.currentScore = 0
        questionText.text = gameBrain.questionList[gameBrain.currentQuestion].question
        questionProgress.text = "Question \(gameBrain.currentQuestion+1) of \(gameBrain.questionList.count)"
    }
    
}
