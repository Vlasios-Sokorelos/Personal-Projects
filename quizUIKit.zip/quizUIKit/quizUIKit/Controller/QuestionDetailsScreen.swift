//
//  QuestionDetailsScreen.swift
//  quizUIKit
//
//  Created by ΒΛΑΣΗΣ ΣΟΚΟΡΕΛΟΣ on 8/6/24.
//

import UIKit

class QuestionDetailsScreen: UIViewController {
    
    var selectedItem: Int?
    let gameBrain = GameBrain.shared
    @IBOutlet weak var questionText: UILabel!
    @IBOutlet weak var questionAnswer: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        if let showSelection = selectedItem {
            
            questionText.text = gameBrain.questionList[showSelection].question
            questionAnswer.text = "Correct answer is: " + gameBrain.questionList[showSelection].answer
            
        }
    }
    


}
