//
//  ViewController.swift
//  quizUIKit
//
//  Created by ΒΛΑΣΗΣ ΣΟΚΟΡΕΛΟΣ on 8/6/24.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var playNormal: UIButton!
    @IBOutlet weak var playRandom: UIButton!
    let gameBrain = GameBrain.shared
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func playNormal(_ sender: UIButton){
        gameBrain.createDefaultGame()
    }
    
    @IBAction func playRandom(_ sender: UIButton) {
        gameBrain.createRandomGame(quizSize: 5)
    }
    
    @IBAction func showQuestions(_ sender: UIButton) {
        gameBrain.createDefaultGame()
        gameBrain.sortList()
    }
    
    @IBAction func unwindToMainScreen(segue: UIStoryboardSegue) {}
}

