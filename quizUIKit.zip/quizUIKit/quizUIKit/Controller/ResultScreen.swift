//
//  ResultScreen.swift
//  quizUIKit
//
//  Created by ΒΛΑΣΗΣ ΣΟΚΟΡΕΛΟΣ on 8/6/24.
//

import UIKit

class ResultScreen: UIViewController {

    @IBOutlet weak var resultText: UILabel!
    let gameBrain = GameBrain.shared
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let userScore = gameBrain.currentScore
        let maxScore = gameBrain.questionList.count
        var result: String
        if (userScore == maxScore){
            result = "Perfect Win!"
        }
        else if (userScore > (maxScore/2)){
            result = "Win!"
        }
        else {
            result = "Loss!"
        }
        let message = "You got \(userScore) out of \(maxScore):\n \(result)"
        resultText.text = message
        
        
    }
    

}
