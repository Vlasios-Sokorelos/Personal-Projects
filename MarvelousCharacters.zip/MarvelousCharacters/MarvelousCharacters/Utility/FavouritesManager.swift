//
//  FavouritesManager.swift
//  MarvelousCharacters
//
//  Created by ΒΛΑΣΗΣ ΣΟΚΟΡΕΛΟΣ on 11/3/25.
//

import Foundation

class FavouritesManager{
private let favoritesKey = "favoriteCharacters"
   static let shared = FavouritesManager()
   
   private init() {}
   
   private var favorites: [String: Bool] {
       get {
           UserDefaults.standard.dictionary(forKey: favoritesKey) as? [String: Bool] ?? [:]
       }
       set {
           UserDefaults.standard.setValue(newValue, forKey: favoritesKey)
       }
   }
   
   func isFavorite(characterName: String) -> Bool {
       return favorites[characterName] ?? false
   }
   
   func toggleFavorite(characterName: String) {
       var currentFavorites = favorites
       currentFavorites[characterName] = !(currentFavorites[characterName] ?? false)
       favorites = currentFavorites
   }
    
    func printFavorites() {
        print("Current Favorites: \(favorites)")
    }
    
}
