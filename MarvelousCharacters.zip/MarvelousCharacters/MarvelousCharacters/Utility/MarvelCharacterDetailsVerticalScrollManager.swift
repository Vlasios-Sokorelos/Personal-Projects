//
//  MarvelCharacterDetailsVerticalScrollManager.swift
//  MarvelousCharacters
//
//  Created by ΒΛΑΣΗΣ ΣΟΚΟΡΕΛΟΣ on 11/3/25.
//

import Foundation


class MarvelCharacterDetailsVerticalScrollManager{
    private static var currentCharacterIndexPosition: Int = 0
    private static var viewModel: MarvelCharactersViewModel = MarvelCharactersViewModel()
    private static var currentMaxPosition: Int = 0
    
    
    public static func setCurrentMaxPositon(){
        currentMaxPosition = viewModel.characters.count - 1
    }
    
    public static func setCurrentIndexPosition(currentPosition: Int){
        self.currentCharacterIndexPosition = currentPosition
    }
    
    public static func getCurrentIndexPositoin() -> Int{
        return self.currentCharacterIndexPosition
    }
    
    public static func getCurrentMaxPosition() ->Int{
        return currentMaxPosition
    }
    
    public static func setPreviousPosition(){
        if(currentCharacterIndexPosition > 0){
            currentCharacterIndexPosition = currentCharacterIndexPosition - 1
        }
        else{
            currentCharacterIndexPosition = 0
        }
    }
    
    public static func setNextPosition() {
        if currentCharacterIndexPosition >= currentMaxPosition {
            viewModel.fetchCharacters { success in
                if success {
                    setCurrentMaxPositon()
                    if self.currentCharacterIndexPosition < currentMaxPosition {
                        self.currentCharacterIndexPosition = currentCharacterIndexPosition + 1
                    }
                }
                else{
                    currentCharacterIndexPosition = currentMaxPosition
                }
            }
        } else if currentCharacterIndexPosition < currentMaxPosition {
            currentCharacterIndexPosition = currentCharacterIndexPosition + 1
        }
    }
    
    public static func loadCharacter() -> MarvelCharacter{
        
        print(viewModel.characters.count)
        return viewModel.characters[currentCharacterIndexPosition]
        
    }
    
    public static func setViewModel(viewModel: MarvelCharactersViewModel){
        self.viewModel = viewModel
        setCurrentMaxPositon()
    }
}
