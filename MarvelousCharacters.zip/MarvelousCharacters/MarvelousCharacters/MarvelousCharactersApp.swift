//
//  MarvelousCharactersApp.swift
//  MarvelousCharacters
//
//  Created by Vlasios Sokorelos on 09/03/2025.
//

import SwiftUI

@main
struct MarvelousCharactersApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
