//
//  MarvelCharacterService.swift
//  MarvelousCharacters
//
//  Created by Vlasios Sokorelos on 09/03/2025.
//

//
//  MarvelAPIService.swift
//  MarvelousCharacters
//
//  Created by Vlasios Sokorelos on 09/03/2025.
//

import Foundation
import CryptoKit

class MarvelAPIService {
    private let baseURL = "https://gateway.marvel.com/v1/public/characters"
    private let publicKey = "cbe19e762ceaecdc7bd61a844d8649dc"
    private let privateKey = "d4d9ae27e93c7e85308ecff0164f283e79c79a2c"
    private let session = URLSession.shared
    
    func fetchCharacters(limit: Int = 10, offset: Int = 0, completion: @escaping (Result<[MarvelCharacter], Error>) -> Void) {
        let timestamp = String(Date().timeIntervalSince1970)
        let hash = generateHash(timestamp: timestamp)
        
        var urlComponents = URLComponents(string: baseURL)
        urlComponents?.queryItems = [
            URLQueryItem(name: "apikey", value: publicKey),
            URLQueryItem(name: "ts", value: timestamp),
            URLQueryItem(name: "hash", value: hash),
            URLQueryItem(name: "limit", value: String(limit)),
            URLQueryItem(name: "offset", value: String(offset)) // Pagination
        ]
        
        guard let url = urlComponents?.url else {
            print("🚨 Invalid URL")
            completion(.failure(NSError(domain: "Invalid URL", code: 0, userInfo: nil)))
            return
        }
        
        print("🌍 Fetching characters from: \(url)")

        let task = session.dataTask(with: url) { data, response, error in
            if let error = error {
                print("❌ Network error: \(error.localizedDescription)")
                completion(.failure(error))
                return
            }

            guard let data = data else {
                print("❌ No data received")
                completion(.failure(NSError(domain: "No data received", code: 0, userInfo: nil)))
                return
            }

            do {
                let marvelResponse = try JSONDecoder().decode(MarvelResponse.self, from: data)
                let characters = marvelResponse.data.results
                print("✅ Loaded \(characters.count) characters")
                completion(.success(characters))
            } catch {
                print("❌ JSON decoding error: \(error.localizedDescription)")
                completion(.failure(error))
            }
        }

        task.resume()
    }

    
    private func generateHash(timestamp: String) -> String {
        let hashString = "\(timestamp)\(privateKey)\(publicKey)"
        let digest = Insecure.MD5.hash(data: hashString.data(using: .utf8)!)
        return digest.map { String(format: "%02hhx", $0) }.joined()
    }
}




