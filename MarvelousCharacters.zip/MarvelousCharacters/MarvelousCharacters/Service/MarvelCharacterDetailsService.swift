//
//  MarvelCharacterDetailsService.swift
//  MarvelousCharacters
//
//  Created by ΒΛΑΣΗΣ ΣΟΚΟΡΕΛΟΣ on 11/3/25.
//

import Foundation
import CryptoKit

class MarvelCharacterDetailsService {
    private let baseURL = "https://gateway.marvel.com/v1/public"
    private let publicKey = "cbe19e762ceaecdc7bd61a844d8649dc"
    private let privateKey = "d4d9ae27e93c7e85308ecff0164f283e79c79a2c"
    
    func fetchCharacter(by name: String) async throws -> MarvelDetailCharacter? {
            let timestamp = String(Date().timeIntervalSince1970)
            let hash = generateHash(timestamp: timestamp)
            let urlString = "\(baseURL)/characters?name=\(name)&ts=\(timestamp)&apikey=\(publicKey)&hash=\(hash)"
            
            print("Fetching Character: \(name)")
            print("Request URL: \(urlString)")

            guard let url = URL(string: urlString) else {
                print("❌ Invalid URL")
                return nil
            }

            let (data, response) = try await URLSession.shared.data(from: url)
            
            if let httpResponse = response as? HTTPURLResponse {
                print("HTTP Status Code: \(httpResponse.statusCode)")
            }
            
            print("Raw JSON Response (Character):")
            print(String(data: data, encoding: .utf8) ?? "❌ Unable to parse data")

            do {
                let response = try JSONDecoder().decode(MarvelDetailsResponse.self, from: data)
                print("✅ Successfully decoded character data")
                return response.data.results.first
            } catch {
                print("❌ Decoding error2: \(error)")
                throw error
            }
        }
    
    func fetchComics(for characterID: Int) async throws -> [MarvelComic] {
            let timestamp = String(Date().timeIntervalSince1970)
            let hash = generateHash(timestamp: timestamp)
            let urlString = "\(baseURL)/characters/\(characterID)/comics?ts=\(timestamp)&apikey=\(publicKey)&hash=\(hash)"

            print("Fetching Comics for Character ID: \(characterID)")
            print("Request URL: \(urlString)")

            guard let url = URL(string: urlString) else {
                print("❌ Invalid URL")
                return []
            }

            let (data, response) = try await URLSession.shared.data(from: url)

            if let httpResponse = response as? HTTPURLResponse {
                print("HTTP Status Code: \(httpResponse.statusCode)")
            }

            print("Raw JSON Response (Comics):")
            print(String(data: data, encoding: .utf8) ?? "❌ Unable to parse data")

            do {
                let response = try JSONDecoder().decode(MarvelComicsResponse.self, from: data)
                print("✅ Successfully decoded comics data")
                return response.data.results
            } catch {
                print("❌ Decoding error1: \(error)")
                throw error
            }
        }
    
    private func generateHash(timestamp: String) -> String {
        let hashString = "\(timestamp)\(privateKey)\(publicKey)"
        let digest = Insecure.MD5.hash(data: Data(hashString.utf8))
        return digest.map { String(format: "%02hhx", $0) }.joined()
    }
}


