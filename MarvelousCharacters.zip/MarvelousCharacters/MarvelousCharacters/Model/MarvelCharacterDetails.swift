//
//  MarvelCharacterDetails.swift
//  MarvelousCharacters
//
//  Created by ΒΛΑΣΗΣ ΣΟΚΟΡΕΛΟΣ on 11/3/25.
//

import Foundation

struct MarvelDetailsResponse: Codable {
    let data: MarvelDetailsData
}

struct MarvelDetailsData: Codable {
    let results: [MarvelDetailCharacter]
}

struct MarvelDetailCharacter: Codable, Identifiable {
    let id: Int
    let name: String
    let description: String?
    let thumbnail: MarvelThumbnail
    var comics: MarvelComicsList?
    
    
    var imageUrl: URL? {
       return thumbnail.url
    }
    

}

struct MarvelComicsList: Codable {
    let items: [MarvelComicSummary]
}

struct MarvelComicSummary: Codable {
    let resourceURI: String
    let name: String
   // let thumbnail: MarvelThumbnail
    
//    var imageUrl: URL? {
//       return thumbnail.url
//    }
}

struct MarvelComicsResponse: Codable {
    let data: MarvelComicsData
}

struct MarvelComicsData: Codable {
    let results: [MarvelComic]
}

struct MarvelComic: Codable, Identifiable {
    let id: Int
    let title: String
    let thumbnail: MarvelThumbnail
    
    var imageUrl: URL? {
       return thumbnail.url
    }
}

extension MarvelComic {
    var comicURI: URL? {
        return URL(string: "https://www.marvel.com/comics/issue/\(id)")
    }
}












