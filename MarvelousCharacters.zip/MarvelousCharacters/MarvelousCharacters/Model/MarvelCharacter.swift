//
//  MarvelCharacter.swift
//  MarvelousCharacters
//
//  Created by Vlasios Sokorelos on 09/03/2025.
//

import Foundation

struct MarvelCharacter: Codable, Identifiable {
    let id: Int
    let name: String
    let thumbnail: MarvelThumbnail
    
    var isFavorite: Bool = false
    
    var imageUrl: URL? {
        return thumbnail.url
    }
    
    private enum CodingKeys: String, CodingKey {
        case id
        case name
        case thumbnail
       
    }
}

struct MarvelResponse: Codable {
    let data: MarvelData
}

struct MarvelData: Codable {
    let results: [MarvelCharacter]
}

struct MarvelThumbnail: Codable {
    let path: String
    let pathExtension: String
    
    var url: URL? {
        let securePath = path.starts(with: "https://") ? path : path.replacingOccurrences(of: "http://", with: "https://")
        return URL(string: "\(securePath).\(pathExtension)")
    }
    
    private enum CodingKeys: String, CodingKey {
        case path
        case pathExtension = "extension"
    }
    
}












