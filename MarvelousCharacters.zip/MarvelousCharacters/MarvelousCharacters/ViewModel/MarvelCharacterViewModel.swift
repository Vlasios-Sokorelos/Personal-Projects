//
//  MarvelCharactersViewModel.swift
//  MarvelousCharacters
//
//  Created by ΒΛΑΣΗΣ ΣΟΚΟΡΕΛΟΣ on 9/3/25.
//

import Foundation
import Combine

class MarvelCharactersViewModel: ObservableObject {
    @Published var characters: [MarvelCharacter] = []
        @Published var isLoading = false
        @Published var errorMessage: String?
        private var cancellables = Set<AnyCancellable>()
        private let marvelService = MarvelAPIService()

        private var offset = 0
        private let limit = 10
        private var canLoadMore = true

    func fetchCharacters(completion: ((Bool) -> Void)? = nil) {
        guard !isLoading, canLoadMore else {
            completion?(false)
            return
        }

        isLoading = true
        errorMessage = nil

        marvelService.fetchCharacters(limit: limit, offset: offset) { [weak self] (result: Result<[MarvelCharacter], Error>) in
            DispatchQueue.main.async {
                self?.isLoading = false
                switch result {
                case .success(let newCharacters):
                    if newCharacters.isEmpty {
                        self?.canLoadMore = false
                        completion?(false)
                    } else {
                        self?.characters.append(contentsOf: newCharacters)
                        self?.offset += self?.limit ?? 10
                        completion?(true)
                    }
                    print("✅ Loaded \(newCharacters.count) more characters, total: \(self?.characters.count ?? 0)")
                case .failure(let error):
                    self?.errorMessage = error.localizedDescription
                    print("❌ Error loading characters: \(error.localizedDescription)")
                    completion?(false)
                }
            }
        }
    }



        func shouldLoadMoreCharacters(currentItem: MarvelCharacter) {
            guard let lastCharacter = characters.dropLast(1).last else { return }
            if currentItem.id == lastCharacter.id {
                fetchCharacters()
            }
        }
    
    
    
    
    
    
    
    
    func toggleFavorite(for characterID: Int){
        if let index = characters.firstIndex(where: { $0.id == characterID }) {
                    characters[index].isFavorite.toggle()
                }
    }
    
}

