//
//  MarvelCharactersDetailsViewModel.swift
//  MarvelousCharacters
//
//  Created by ΒΛΑΣΗΣ ΣΟΚΟΡΕΛΟΣ on 11/3/25.
//


import Foundation
import Combine

class MarvelCharacterDetailsViewModel: ObservableObject {
    @Published var character: MarvelDetailCharacter?
    @Published var comics: [MarvelComic] = []
    @Published var isLoading = false
    
    private let service = MarvelCharacterDetailsService()
    
    func loadCharacter(named name: String) {
        isLoading = true
        Task {
            do {
                if let fetchedCharacter = try await service.fetchCharacter(by: name) {
                    DispatchQueue.main.async {
                        print("test2")
                        self.character = fetchedCharacter
                    }
                    
                    let fetchedComics = try await service.fetchComics(for: fetchedCharacter.id)
                    DispatchQueue.main.async {
                        print("test1")
                        self.comics = fetchedComics
                    }
                }
            } catch {
                print("Error fetching data: \(error)")
            }
            DispatchQueue.main.async {
                self.isLoading = false
            }
        }
    }
}




