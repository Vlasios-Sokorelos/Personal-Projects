//
//  CharacterDetailsView.swift
//  MarvelousCharacters
//
//  Created by Vlasios Sokorelos on 09/03/2025.
//

import SwiftUI

import SwiftUI

struct CharacterDetailsView: View {
    @StateObject var viewModel = MarvelCharacterDetailsViewModel()
    @State private var isFavorite: Bool = false
    @State public var character: MarvelCharacter


    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            // Character Image
            AsyncImage(url: viewModel.character?.thumbnail.url) { image in
                image.resizable()
                    .scaledToFit()
                    .frame(height: 200)
                    .cornerRadius(8)
            } placeholder: {
                Color.gray.opacity(0.3)
                    .frame(height: 200)
                    .cornerRadius(8)
            }

            HStack {
                // Name
                Text(viewModel.character?.name ?? "Error")
                    .font(.title2)
                    .fontWeight(.bold)
                    .foregroundColor(.white)

                Spacer()

                // Favorite Button
                Button(action: {
                    isFavorite.toggle()
                    FavouritesManager.shared.toggleFavorite(characterName: viewModel.character?.name ?? "Error")
                }) {
                    Image(systemName: isFavorite ? "star.fill" : "star")
                        .foregroundColor(isFavorite ? .yellow : .gray)
                }
                .buttonStyle(.plain)
            }
            .background(Color.black)

            // Description
            Text(viewModel.character?.description ?? "No data available")
                .font(.footnote)
                .foregroundColor(.black)
                .lineLimit(nil)

            // Comics Section
            if !viewModel.comics.isEmpty {
                HStack {
                    Text("Comics")
                        .font(.title3)
                        .fontWeight(.bold)
                    Spacer()
                }
                .foregroundColor(.white)
                .background(Color.black)

                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(viewModel.comics) { comic in
                            NavigationLink(destination: ComicDetailsView(comicUrl: comic.comicURI ?? URL(string: "https://www.marvel.com")!)) {
                                VStack {
                                    AsyncImage(url: comic.imageUrl) { image in
                                        image.resizable()
                                            .scaledToFit()
                                    } placeholder: {
                                        Color.gray.opacity(0.3)
                                    }
                                    .frame(width: 100, height: 150)
                                    .cornerRadius(6)

                                    Text(comic.title)
                                        .font(.caption)
                                        .multilineTextAlignment(.center)
                                        .frame(width: 100, height: 50)
                                        .foregroundColor(.white)
                                        .border(Color.red)
                                }
                                .background(Color.black)
                                .border(Color.white)
                            }
                        }
                    }
                }
            }

            Spacer()
        }
        .padding()
        .background(Color.red)
        .cornerRadius(12)
        .gesture(
            DragGesture()
                .onEnded { value in
                    if value.translation.height < -50 { // Swipe Up: Next Character
                        MarvelCharacterDetailsVerticalScrollManager.setNextPosition()
                    } else if value.translation.height > 50 { // Swipe Down: Previous Character
                        MarvelCharacterDetailsVerticalScrollManager.setPreviousPosition()
                    }
                    
                    viewModel.loadCharacter(named: MarvelCharacterDetailsVerticalScrollManager.loadCharacter().name)
                }
        )
        .onAppear {
            viewModel.loadCharacter(named: character.name)
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) { // Slight delay to allow async update
                    if let characterName = viewModel.character?.name {
                        isFavorite = FavouritesManager.shared.isFavorite(characterName: characterName)
                    }
                }

        }
    }
}

struct CharacterDetailsView_Previews: PreviewProvider {
    static var previews: some View {
        let sampleCharacter = MarvelCharacter(
            id: 1009368,
            name: "Iron Man",
            thumbnail: MarvelThumbnail(path: "https://i.annihil.us/u/prod/marvel/i/mg/9/c0/527bb7b37ff55", pathExtension: "jpg")
        )

        CharacterDetailsView(character: sampleCharacter)
    }
}
