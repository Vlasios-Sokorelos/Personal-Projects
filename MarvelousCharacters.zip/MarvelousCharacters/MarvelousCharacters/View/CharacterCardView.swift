//
//  CharacterCardView.swift
//  MarvelousCharacters
//
//  Created by Vlasios Sokorelos on 09/03/2025.
//

import SwiftUI

struct CharacterCardView: View {
    @Binding var character: MarvelCharacter // Binding to the character
    @ObservedObject var viewModel: MarvelCharactersViewModel // ViewModel
    @State private var isFavorite: Bool = false // State for favorite status
    
    var body: some View {
        VStack {
            Spacer()
            
            NavigationLink(destination: CharacterDetailsView(character: character)) {
                ZStack {
                    Rectangle()
                        .fill(Color.clear)
                        .frame(width: 160, height: 140)
                    
                    if let imageUrl = character.thumbnail.url {
                        AsyncImage(url: imageUrl) { phase in
                            switch phase {
                            case .success(let image):
                                image.resizable()
                                    .scaledToFit()
                            case .failure(_):
                                Image(systemName: "photo")
                                    .resizable()
                                    .scaledToFit()
                                    .foregroundColor(.gray)
                            default:
                                ProgressView()
                            }
                        }
                    } else {
                        Image(systemName: "photo")
                            .resizable()
                            .scaledToFit()
                            .foregroundColor(.gray)
                    }
                }
            }
            .buttonStyle(PlainButtonStyle())
            
            Spacer()
            
            HStack {
                Text(character.name)
                    .font(.caption)
                    .lineLimit(2)
                    .frame(maxWidth: .infinity, alignment: .leading)
                
                Button(action: {
                    isFavorite.toggle()
                    FavouritesManager.shared.toggleFavorite(characterName: character.name)
                }) {
                    Image(systemName: isFavorite ? "star.fill" : "star")
                        .foregroundColor(.yellow)
                }
            }
            .padding(5)
            .background(Color.white)
            .border(Color.black)
        }
        .foregroundColor(Color.black)
        .padding()
        .frame(width: 170, height: 220)
        .background(Color.red)
        .cornerRadius(12)
        .shadow(radius: 5)
        .onAppear {
            isFavorite = FavouritesManager.shared.isFavorite(characterName: character.name)
        }
    }
}

struct CharacterCardView_Previews: PreviewProvider {
    static var previews: some View {
        // Create a sample character object for the preview
        let placeholderCharacter = MarvelCharacter(
            id: 0,
            name: "Placeholder Hero",
            thumbnail: MarvelThumbnail(path: "https://via.placeholder.com/150", pathExtension: "jpg"),
            
            isFavorite: false
        )
        
        // Pass the character as a constant binding for the preview
        CharacterCardView(
            character: .constant(placeholderCharacter),
            viewModel: MarvelCharactersViewModel()
        )
    }
}

