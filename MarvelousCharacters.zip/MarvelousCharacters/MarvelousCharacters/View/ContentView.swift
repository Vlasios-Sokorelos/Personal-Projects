//
//  ContentView.swift
//  MarvelousCharacters
//
//  Created by Vlasios Sokorelos on 09/03/2025.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView{
            NavigationView{
                CharacterListView()
                    .navigationBarTitleDisplayMode(.inline)
                    .navigationBarTitle("Marvel Characters", displayMode: .inline) // Set the title of the navigation bar
                            
            }.tabItem{Label("Marvel Characters",systemImage: "person")}
            NavigationView{
                SettingsView()
            }.tabItem{Label("Settings",systemImage: "gear")}
        }
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
