//
//  ComicDetailsView.swift
//  MarvelousCharacters
//
//  Created by Vlasios Sokorelos on 09/03/2025.
//

import SwiftUI
import WebKit

struct ComicDetailsView: View {
    let comicUrl: URL

    var body: some View {
        WebView(url: comicUrl)
            .navigationTitle("Comic Details")
            .navigationBarTitleDisplayMode(.inline)
    }
}

struct ComicDetailsView_Previews: PreviewProvider {
    static var previews: some View {
        ComicDetailsView(comicUrl: URL(string: "https://www.google.com")!)
    }
}

struct WebView: UIViewRepresentable {
    let url: URL

    func makeUIView(context: Context) -> WKWebView {
        return WKWebView()
    }

    func updateUIView(_ webView: WKWebView, context: Context) {
        let request = URLRequest(url: url)
        webView.load(request)
    }
}
