//
//  SettingsView.swift
//  MarvelousCharacters
//
//  Created by Vlasios Sokorelos on 09/03/2025.
//

import SwiftUI

struct SettingsView: View {
    @AppStorage("isDarkMode") private var isDarkMode: Bool = false
    @Environment(\.colorScheme) private var systemColorScheme

    var body: some View {
        VStack {
            Toggle("Dark Mode", isOn: $isDarkMode)
                .padding()
        }
        .onAppear {
            // Always reset to system theme on app launch
            isDarkMode = (systemColorScheme == .dark)
        }
        .preferredColorScheme(isDarkMode ? .dark : .light)
    }
}





struct SettingsView_Previews: PreviewProvider {
    static var previews: some View {
        SettingsView()
    }
}
