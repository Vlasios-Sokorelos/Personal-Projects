//
//  CharacterListView.swift
//  MarvelousCharacters
//
//  Created by Vlasios Sokorelos on 09/03/2025.
//

import SwiftUI

import SwiftUI

struct CharacterListView: View {
    @StateObject private var viewModel = MarvelCharactersViewModel()
    let gridColumns = [GridItem(.flexible()), GridItem(.flexible())]

    var body: some View {
        ScrollView {
            LazyVGrid(columns: gridColumns, spacing: 10) {
                ForEach(viewModel.characters.indices, id: \.self) { index in
                    CharacterCardView(character: $viewModel.characters[index], viewModel: viewModel)
                        .simultaneousGesture(TapGesture().onEnded {
                            MarvelCharacterDetailsVerticalScrollManager.setCurrentIndexPosition(currentPosition: index)
                        })
                        .onAppear {
                            MarvelCharacterDetailsVerticalScrollManager.setViewModel(viewModel: viewModel)
                            
                            // **Pagination Trigger**
                            if index == viewModel.characters.count - 2 {
                                viewModel.fetchCharacters()
                            }
                        }
                }

                if viewModel.isLoading {
                    ProgressView()
                        .padding()
                }
            }
            .padding()
            .onAppear {
                if viewModel.characters.isEmpty {
                    viewModel.fetchCharacters()
                }
            }
        }
    }
}




struct CharacterListView_Previews: PreviewProvider {
    static var previews: some View {
        CharacterListView()
    }
}
